package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
  private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
  private val displayFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
  private val shortDisplayFormat = SimpleDateFormat("MMM d", Locale.getDefault())
  private val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())

  fun todayIso(): String {
    return isoFormat.format(Date())
  }

  fun yesterdayIso(): String {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    return isoFormat.format(cal.time)
  }

  fun formatIsoDate(date: Date): String {
    return isoFormat.format(date)
  }

  fun formatDisplayDate(iso: String): String {
    return try {
      val date = isoFormat.parse(iso) ?: Date()
      displayFormat.format(date)
    } catch (e: Exception) {
      iso
    }
  }

  fun formatShortDate(iso: String): String {
    return try {
      val date = isoFormat.parse(iso) ?: Date()
      shortDisplayFormat.format(date)
    } catch (e: Exception) {
      iso
    }
  }

  fun formatTime(timestamp: Long): String {
    return timeFormat.format(Date(timestamp))
  }

  fun getGreeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
      in 5..11 -> "Good morning"
      in 12..16 -> "Good afternoon"
      in 17..21 -> "Good evening"
      else -> "Good night"
    }
  }

  fun getLastNDaysIso(n: Int): List<String> {
    val list = mutableListOf<String>()
    val cal = Calendar.getInstance()
    // Move to n-1 days ago up to today
    cal.add(Calendar.DAY_OF_YEAR, -(n - 1))
    for (i in 0 until n) {
      list.add(isoFormat.format(cal.time))
      cal.add(Calendar.DAY_OF_YEAR, 1)
    }
    return list
  }

  fun getDayOfWeekShort(iso: String): String {
    return try {
      val date = isoFormat.parse(iso) ?: return ""
      SimpleDateFormat("EEE", Locale.getDefault()).format(date)
    } catch (e: Exception) {
      ""
    }
  }

  fun parseIso(iso: String): Date? {
    return try {
      isoFormat.parse(iso)
    } catch (e: Exception) {
      null
    }
  }

  fun getStartOfDay(timestamp: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance()
    cal.timeInMillis = timestamp
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
  }

  fun getStartOfYesterday(): Long {
    val cal = Calendar.getInstance()
    cal.timeInMillis = getStartOfDay()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    return cal.timeInMillis
  }
}
