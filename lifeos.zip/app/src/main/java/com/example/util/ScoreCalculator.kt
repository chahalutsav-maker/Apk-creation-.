package com.example.util

import kotlin.math.roundToInt

data class DailyScoreResult(
  val totalScore: Int,
  val stepsScore: Int,
  val waterScore: Int,
  val sleepScore: Int,
  val tasksScore: Int,
  val habitsScore: Int,
  val message: String
)

data class ConsistencyStats(
  val consistencyPercentage: Int,
  val currentStreak: Int,
  val bestStreak: Int,
  val daysActive: Int,
  val missedDays: Int
)

object ScoreCalculator {

  /**
   * Calculates a transparent, weighted Daily Lifestyle Score from 0 to 100:
   * - Steps: 20 points
   * - Water: 20 points
   * - Sleep: 20 points
   * - Tasks: 20 points
   * - Habits: 20 points
   */
  fun calculateDailyScore(
    steps: Int,
    stepTarget: Int,
    waterMl: Int,
    waterTargetMl: Int,
    sleepMinutes: Int,
    sleepTargetMinutes: Int,
    tasksCompleted: Int,
    tasksTotal: Int,
    habitsCompleted: Int,
    habitsTotal: Int
  ): DailyScoreResult {
    // 1. Steps (up to 20 pts)
    val stepRatio = if (stepTarget > 0) (steps.toDouble() / stepTarget).coerceIn(0.0, 1.0) else 1.0
    val stepsScore = (stepRatio * 20).roundToInt()

    // 2. Water (up to 20 pts)
    val waterRatio = if (waterTargetMl > 0) (waterMl.toDouble() / waterTargetMl).coerceIn(0.0, 1.0) else 1.0
    val waterScore = (waterRatio * 20).roundToInt()

    // 3. Sleep (up to 20 pts)
    val sleepRatio = if (sleepTargetMinutes > 0 && sleepMinutes > 0) {
      (sleepMinutes.toDouble() / sleepTargetMinutes).coerceIn(0.0, 1.0)
    } else {
      // If no sleep tracked yet, award baseline 14 points if steps/habits are active
      if (steps > 0 || waterMl > 0) 14.0 / 20.0 else 0.0
    }
    val sleepScore = (sleepRatio * 20).roundToInt()

    // 4. Tasks (up to 20 pts)
    val tasksScore = if (tasksTotal > 0) {
      ((tasksCompleted.toDouble() / tasksTotal) * 20).roundToInt()
    } else {
      20 // If no tasks planned, neutral full score
    }

    // 5. Habits (up to 20 pts)
    val habitsScore = if (habitsTotal > 0) {
      ((habitsCompleted.toDouble() / habitsTotal) * 20).roundToInt()
    } else {
      20 // If no habits created, neutral
    }

    val total = (stepsScore + waterScore + sleepScore + tasksScore + habitsScore).coerceIn(0, 100)

    val message = when {
      total >= 90 -> "Outstanding performance! Peak discipline unlocked."
      total >= 80 -> "Great day! Keep your streak and momentum alive."
      total >= 70 -> "Solid progress! Close in on your remaining targets."
      total >= 50 -> "Good momentum. A few more wins to boost your score!"
      else -> "Take action today. Small steps compound into greatness."
    }

    return DailyScoreResult(
      totalScore = total,
      stepsScore = stepsScore,
      waterScore = waterScore,
      sleepScore = sleepScore,
      tasksScore = tasksScore,
      habitsScore = habitsScore,
      message = message
    )
  }

  /**
   * Calculates overall consistency percentage and streak analytics across days
   */
  fun calculateConsistency(
    recentDailyScores: List<Int>,
    totalActiveDays: Int,
    currentHabitStreak: Int,
    bestHabitStreak: Int
  ): ConsistencyStats {
    if (recentDailyScores.isEmpty()) {
      return ConsistencyStats(
        consistencyPercentage = 85,
        currentStreak = currentHabitStreak.coerceAtLeast(1),
        bestStreak = bestHabitStreak.coerceAtLeast(1),
        daysActive = totalActiveDays.coerceAtLeast(1),
        missedDays = 0
      )
    }

    val averageScore = recentDailyScores.average().roundToInt()
    val missed = recentDailyScores.count { it < 40 }
    val effectiveDaysActive = (totalActiveDays).coerceAtLeast(recentDailyScores.size)

    return ConsistencyStats(
      consistencyPercentage = averageScore.coerceIn(10, 100),
      currentStreak = currentHabitStreak.coerceAtLeast(1),
      bestStreak = maxOf(bestHabitStreak, currentHabitStreak).coerceAtLeast(1),
      daysActive = effectiveDaysActive,
      missedDays = missed
    )
  }
}
