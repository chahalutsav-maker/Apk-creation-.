package com.example.ui.screens.tasks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TaskItem
import com.example.ui.viewmodel.LifeOsViewModel
import com.example.util.DateUtils

@Composable
fun TasksScreen(
  viewModel: LifeOsViewModel,
  onAddTaskClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val allTasks by viewModel.allTasks.collectAsState()
  val todayIso = viewModel.todayIso

  var statusFilter by remember { mutableStateOf("Today") } // "All", "Today", "Upcoming", "Completed"
  var categoryFilter by remember { mutableStateOf("All") } // "All", "Personal", "Work", "Fitness", "Study", "Health"
  var sortBy by remember { mutableStateOf("Due Time") } // "Due Time", "Priority", "Date Created"

  val statusFilters = listOf("Today", "Upcoming", "All", "Completed")
  val categories = listOf("All", "Personal", "Work", "Fitness", "Study", "Health")
  val sortOptions = listOf("Due Time", "Priority", "Date Created")

  // Filter tasks
  val filteredTasks = allTasks.filter { task ->
    val matchesStatus = when (statusFilter) {
      "Today" -> task.dueDate == todayIso && !task.isCompleted
      "Upcoming" -> task.dueDate > todayIso && !task.isCompleted
      "Completed" -> task.isCompleted
      else -> true
    }
    val matchesCategory = if (categoryFilter == "All") true else task.category == categoryFilter
    matchesStatus && matchesCategory
  }.sortedWith { a, b ->
    when (sortBy) {
      "Priority" -> {
        val pA = if (a.priority == "High") 3 else if (a.priority == "Medium") 2 else 1
        val pB = if (b.priority == "High") 3 else if (b.priority == "Medium") 2 else 1
        pB.compareTo(pA)
      }
      "Date Created" -> b.createdAt.compareTo(a.createdAt)
      else -> a.dueTime.compareTo(b.dueTime)
    }
  }

  val completedCount = allTasks.count { it.isCompleted }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header
      item {
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Tasks",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.onBackground
            )
            Text(
              text = "$completedCount of ${allTasks.size} tasks finished",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.clickable {
              sortBy = when (sortBy) {
                "Due Time" -> "Priority"
                "Priority" -> "Date Created"
                else -> "Due Time"
              }
            }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Filled.Sort, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(sortBy, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }

      // Status Filter Chips
      item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(statusFilters) { sf ->
            FilterChip(
              selected = statusFilter == sf,
              onClick = { statusFilter = sf },
              label = { Text(sf) },
              modifier = Modifier.testTag("filter_status_$sf")
            )
          }
        }
      }

      // Category Filter Chips
      item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = categoryFilter == cat,
              onClick = { categoryFilter = cat },
              label = { Text(cat, fontSize = 12.sp) }
            )
          }
        }
      }

      // Empty State
      if (filteredTasks.isEmpty()) {
        item {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(36.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("No tasks found in $statusFilter", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
              Spacer(modifier = Modifier.height(6.dp))
              Text("Tap the + button to schedule your next win.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(filteredTasks, key = { it.id }) { task ->
          TaskCardItem(
            task = task,
            onToggle = { viewModel.toggleTask(task) },
            onDelete = { viewModel.deleteTask(task) }
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(84.dp))
      }
    }

    // FAB Add Task
    FloatingActionButton(
      onClick = onAddTaskClick,
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = MaterialTheme.colorScheme.onPrimary,
      shape = RoundedCornerShape(18.dp),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 20.dp, bottom = 80.dp)
        .testTag("fab_add_task")
    ) {
      Icon(Icons.Filled.Add, contentDescription = "Add Task")
    }
  }
}

@Composable
private fun TaskCardItem(
  task: TaskItem,
  onToggle: () -> Unit,
  onDelete: () -> Unit
) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val cardBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)

  val priorityColor = when (task.priority) {
    "High" -> Color(0xFFDC2626)
    "Medium" -> Color(0xFFD97706)
    else -> Color(0xFF2563EB)
  }
  val priorityBg = when (task.priority) {
    "High" -> if (isDark) Color(0xFF450A0A) else Color(0xFFFEE2E2)
    "Medium" -> if (isDark) Color(0xFF451A03) else Color(0xFFFEF3C7)
    else -> if (isDark) Color(0xFF172554) else Color(0xFFDBEAFE)
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) {
        MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    border = BorderStroke(1.dp, cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = task.isCompleted,
        onCheckedChange = { onToggle() },
        colors = CheckboxDefaults.colors(
          checkedColor = MaterialTheme.colorScheme.primary,
          uncheckedColor = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
        ),
        modifier = Modifier.testTag("task_checkbox_${task.id}")
      )

      Spacer(modifier = Modifier.width(8.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          style = MaterialTheme.typography.bodyLarge,
          fontWeight = if (task.isCompleted) FontWeight.Normal else FontWeight.Bold,
          color = if (task.isCompleted) {
            if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
          } else {
            MaterialTheme.colorScheme.onSurface
          }
        )

        if (task.notes.isNotBlank()) {
          Text(
            text = task.notes,
            style = MaterialTheme.typography.bodySmall,
            color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
            maxLines = 2
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (task.dueTime.isNotBlank()) {
            Text(task.dueTime, fontSize = 11.sp, color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B))
            Text(" • ", fontSize = 11.sp, color = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8))
          }
          Text(task.category, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
          Text(" • ", fontSize = 11.sp, color = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8))
          Text(DateUtils.formatShortDate(task.dueDate), fontSize = 11.sp, color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B))
        }
      }

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = priorityBg
      ) {
        Text(
          text = task.priority,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = priorityColor,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
      }

      Spacer(modifier = Modifier.width(4.dp))

      IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
        Icon(Icons.Filled.Delete, contentDescription = "Delete Task", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
      }
    }
  }
}
