package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class BarChartItem(
  val label: String,
  val value: Float,
  val isHighlight: Boolean = false
)

@Composable
fun MiniBarChart(
  title: String,
  subtitle: String,
  items: List<BarChartItem>,
  targetValue: Float? = null,
  barColor: Color = MaterialTheme.colorScheme.primary,
  unit: String = "",
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        if (targetValue != null && targetValue > 0) {
          Text(
            text = "Target: ${targetValue.toInt()} $unit",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      val maxValue = maxOf((items.maxOfOrNull { it.value } ?: 1f), (targetValue ?: 1f))

      Canvas(
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp)
      ) {
        val count = items.size
        if (count == 0) return@Canvas

        val spacing = 8.dp.toPx()
        val totalSpacing = spacing * (count + 1)
        val barWidth = ((size.width - totalSpacing) / count).coerceIn(12.dp.toPx(), 36.dp.toPx())
        val chartHeight = size.height - 18.dp.toPx()

        // Optional target threshold line
        if (targetValue != null && targetValue > 0) {
          val targetY = chartHeight - (targetValue / maxValue * chartHeight)
          drawLine(
            color = barColor.copy(alpha = 0.35f),
            start = Offset(0f, targetY),
            end = Offset(size.width, targetY),
            strokeWidth = 2.dp.toPx()
          )
        }

        items.forEachIndexed { index, item ->
          val left = spacing + index * (barWidth + spacing)
          val barHeight = if (maxValue > 0) (item.value / maxValue * chartHeight).coerceAtLeast(4f) else 4f
          val top = chartHeight - barHeight

          val effectiveColor = if (item.isHighlight) {
            barColor
          } else {
            barColor.copy(alpha = 0.45f)
          }

          // Draw rounded bar
          drawRoundRect(
            color = effectiveColor,
            topLeft = Offset(left, top),
            size = Size(barWidth, barHeight),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // X-Axis labels
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        items.forEach { item ->
          Text(
            text = item.label,
            fontSize = 10.sp,
            fontWeight = if (item.isHighlight) FontWeight.Bold else FontWeight.Normal,
            color = if (item.isHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
