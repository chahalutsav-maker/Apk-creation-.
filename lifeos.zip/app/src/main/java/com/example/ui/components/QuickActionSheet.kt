package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentStreak
import com.example.ui.theme.AccentWater

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickActionFab(
  onAddTask: () -> Unit,
  onAddHabit: () -> Unit,
  onAddWater: () -> Unit,
  onAddGoal: () -> Unit,
  onStartChallenge: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showSheet by remember { mutableStateOf(false) }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  FloatingActionButton(
    onClick = { showSheet = true },
    containerColor = MaterialTheme.colorScheme.primary,
    contentColor = MaterialTheme.colorScheme.onPrimary,
    shape = RoundedCornerShape(18.dp),
    modifier = modifier.testTag("fab_quick_action")
  ) {
    Icon(
      imageVector = Icons.Filled.Add,
      contentDescription = "Quick Actions",
      modifier = Modifier.size(28.dp)
    )
  }

  if (showSheet) {
    ModalBottomSheet(
      onDismissRequest = { showSheet = false },
      sheetState = sheetState,
      containerColor = MaterialTheme.colorScheme.surface,
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 24.dp)
          .padding(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Text(
          text = "Quick Action",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "Instantly log or start something new in LifeOS",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(6.dp))

        QuickActionRowItem(
          icon = Icons.Filled.CheckCircle,
          title = "Add Task",
          subtitle = "Create a task with priority and due time",
          color = MaterialTheme.colorScheme.primary,
          onClick = {
            showSheet = false
            onAddTask()
          },
          testTag = "quick_action_add_task"
        )

        QuickActionRowItem(
          icon = Icons.Filled.Repeat,
          title = "Add Habit",
          subtitle = "Establish a routine and build a daily streak",
          color = MaterialTheme.colorScheme.secondary,
          onClick = {
            showSheet = false
            onAddHabit()
          },
          testTag = "quick_action_add_habit"
        )

        QuickActionRowItem(
          icon = Icons.Filled.LocalDrink,
          title = "Add Water (+250ml)",
          subtitle = "Quickly log water towards your daily goal",
          color = AccentWater,
          onClick = {
            showSheet = false
            onAddWater()
          },
          testTag = "quick_action_add_water"
        )

        QuickActionRowItem(
          icon = Icons.Filled.Flag,
          title = "Add Goal",
          subtitle = "Set a numeric target across steps, habits, or tasks",
          color = AccentStreak,
          onClick = {
            showSheet = false
            onAddGoal()
          },
          testTag = "quick_action_add_goal"
        )

        QuickActionRowItem(
          icon = Icons.Filled.EmojiEvents,
          title = "Start Challenge",
          subtitle = "Join 30, 60, 75, or 90 day discipline challenges",
          color = Color(0xFFEAB308),
          onClick = {
            showSheet = false
            onStartChallenge()
          },
          testTag = "quick_action_start_challenge"
        )
      }
    }
  }
}

@Composable
private fun QuickActionRowItem(
  icon: ImageVector,
  title: String,
  subtitle: String,
  color: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = color.copy(alpha = 0.15f),
        modifier = Modifier.size(44.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
