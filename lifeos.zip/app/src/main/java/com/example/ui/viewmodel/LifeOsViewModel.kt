package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LifeOsDatabase
import com.example.data.model.Achievement
import com.example.data.model.ChallengeItem
import com.example.data.model.DailyRecord
import com.example.data.model.GoalItem
import com.example.data.model.HabitItem
import com.example.data.model.HabitLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import com.example.data.repository.LifeOsRepository
import com.example.service.HealthAndSensorManager
import com.example.service.NotificationHelper
import com.example.service.ScreenTimeStats
import com.example.service.UsageStatsHelper
import com.example.util.ConsistencyStats
import com.example.util.DailyScoreResult
import com.example.util.DateUtils
import com.example.util.ScoreCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HabitUiModel(
  val habit: HabitItem,
  val isCompletedToday: Boolean,
  val completionRate: Int
)

data class DayAnalyticsPoint(
  val dateIso: String,
  val dayLabel: String,
  val steps: Int,
  val waterMl: Int,
  val sleepMinutes: Int,
  val dailyScore: Int,
  val tasksCompleted: Int,
  val habitsCompleted: Int,
  val screenTimeMinutes: Int
)

data class CalendarDaySummary(
  val dateIso: String,
  val displayDate: String,
  val tasksCompleted: Int,
  val tasksTotal: Int,
  val habitsCompleted: Int,
  val habitsTotal: Int,
  val waterMl: Int,
  val waterTargetMl: Int,
  val steps: Int,
  val stepTarget: Int,
  val sleepMinutes: Int,
  val dailyScore: Int
)

class LifeOsViewModel(application: Application) : AndroidViewModel(application) {

  private val database = LifeOsDatabase.getDatabase(application, viewModelScope)
  val repository = LifeOsRepository(database.lifeOsDao())
  val sensorManager = HealthAndSensorManager(application)

  val todayIso = DateUtils.todayIso()

  // --- USER PROFILE ---
  val userProfile: StateFlow<UserProfile?> = repository.userProfile
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  // --- TASKS ---
  val allTasks: StateFlow<List<TaskItem>> = repository.allTasks
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val todayTasks: StateFlow<List<TaskItem>> = repository.getTasksForDate(todayIso)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // --- HABITS ---
  val allHabits: StateFlow<List<HabitItem>> = repository.allHabits
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val todayHabitLogs: StateFlow<List<HabitLog>> = repository.getHabitLogsForDate(todayIso)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val habitsWithStatus: StateFlow<List<HabitUiModel>> = combine(allHabits, todayHabitLogs) { habits, logs ->
    val completedIds = logs.map { it.habitId }.toSet()
    habits.map { habit ->
      val rate = if (habit.totalCompletions > 0) {
        ((habit.totalCompletions.toDouble() / maxOf(30, habit.totalCompletions)) * 100).toInt().coerceIn(10, 100)
      } else {
        0
      }
      HabitUiModel(
        habit = habit,
        isCompletedToday = completedIds.contains(habit.id),
        completionRate = rate
      )
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // --- WATER ---
  val todayWaterLogs: StateFlow<List<WaterLog>> = repository.getWaterLogsForDate(todayIso)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val todayWaterTotal: StateFlow<Int> = repository.getWaterTotalForDate(todayIso)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

  // --- STEPS & SLEEP ---
  private val _manualSteps = MutableStateFlow(0)
  val manualSteps: StateFlow<Int> = _manualSteps.asStateFlow()

  private val _todaySleepMinutes = MutableStateFlow(450) // default 7h 30m
  val todaySleepMinutes: StateFlow<Int> = _todaySleepMinutes.asStateFlow()

  private val _sleepBedtime = MutableStateFlow("11:15 PM")
  val sleepBedtime: StateFlow<String> = _sleepBedtime.asStateFlow()

  private val _sleepWakeTime = MutableStateFlow("06:45 AM")
  val sleepWakeTime: StateFlow<String> = _sleepWakeTime.asStateFlow()

  private val _sleepQuality = MutableStateFlow("Good")
  val sleepQuality: StateFlow<String> = _sleepQuality.asStateFlow()

  // --- SCREEN TIME ---
  private val _screenTimeStats = MutableStateFlow(UsageStatsHelper.getScreenTimeStats(application))
  val screenTimeStats: StateFlow<ScreenTimeStats> = _screenTimeStats.asStateFlow()

  // --- GOALS & CHALLENGES & ACHIEVEMENTS ---
  val allGoals: StateFlow<List<GoalItem>> = repository.allGoals
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allChallenges: StateFlow<List<ChallengeItem>> = repository.allChallenges
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allAchievements: StateFlow<List<Achievement>> = repository.allAchievements
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // --- CALENDAR SELECTED DATE ---
  private val _selectedCalendarDate = MutableStateFlow(todayIso)
  val selectedCalendarDate: StateFlow<String> = _selectedCalendarDate.asStateFlow()

  private val _calendarSummary = MutableStateFlow<CalendarDaySummary?>(null)
  val calendarSummary: StateFlow<CalendarDaySummary?> = _calendarSummary.asStateFlow()

  // --- DAILY SCORE ---
  private val healthMetrics = combine(
    userProfile,
    todayWaterTotal,
    manualSteps,
    todaySleepMinutes
  ) { profile, water, steps, sleep ->
    Triple(profile, Pair(water, steps), sleep)
  }

  private val taskHabitMetrics = combine(
    todayTasks,
    habitsWithStatus
  ) { tasks, habits ->
    Pair(tasks, habits)
  }

  val todayDailyScore: StateFlow<DailyScoreResult> = combine(
    healthMetrics,
    taskHabitMetrics
  ) { health, taskHabit ->
    val profile = health.first
    val water = health.second.first
    val steps = health.second.second
    val sleep = health.third
    val tasks = taskHabit.first
    val habits = taskHabit.second

    val targetSteps = profile?.stepTarget ?: 10000
    val targetWater = profile?.waterTargetMl ?: 2500
    val targetSleep = profile?.sleepTargetMinutes ?: 480
    val tasksCompleted = tasks.count { it.isCompleted }
    val tasksTotal = tasks.size
    val habitsCompleted = habits.count { it.isCompletedToday }
    val habitsTotal = habits.size

    ScoreCalculator.calculateDailyScore(
      steps = steps,
      stepTarget = targetSteps,
      waterMl = water,
      waterTargetMl = targetWater,
      sleepMinutes = sleep,
      sleepTargetMinutes = targetSleep,
      tasksCompleted = tasksCompleted,
      tasksTotal = tasksTotal,
      habitsCompleted = habitsCompleted,
      habitsTotal = habitsTotal
    )
  }.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    DailyScoreResult(82, 16, 18, 16, 16, 16, "Great day! Keep your streak and momentum alive.")
  )

  // --- CONSISTENCY STATS ---
  val consistencyStats: StateFlow<ConsistencyStats> = combine(
    allHabits,
    todayDailyScore
  ) { habits, dailyScore ->
    val maxCurrent = habits.maxOfOrNull { it.currentStreak } ?: 5
    val maxBest = habits.maxOfOrNull { it.bestStreak } ?: 12
    ScoreCalculator.calculateConsistency(
      recentDailyScores = listOf(84, 88, 79, 91, 85, dailyScore.totalScore),
      totalActiveDays = 14,
      currentHabitStreak = maxCurrent,
      bestHabitStreak = maxBest
    )
  }.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    ConsistencyStats(87, 5, 12, 14, 1)
  )

  // --- 7-DAY ANALYTICS DATA ---
  private val _analyticsPeriod = MutableStateFlow("7 days") // "7 days", "30 days", "90 days"
  val analyticsPeriod: StateFlow<String> = _analyticsPeriod.asStateFlow()

  private val _analyticsData = MutableStateFlow<List<DayAnalyticsPoint>>(emptyList())
  val analyticsData: StateFlow<List<DayAnalyticsPoint>> = _analyticsData.asStateFlow()

  init {
    NotificationHelper.createNotificationChannels(application)
    refreshScreenTime()
    loadCalendarDay(todayIso)
    generateAnalytics(7)

    // Listen to step sensor if available
    sensorManager.onStepCountUpdated = { sensorSteps ->
      if (sensorSteps > 0) {
        _manualSteps.value = sensorSteps
      }
    }
    sensorManager.startListening()
  }

  fun setAnalyticsPeriod(period: String) {
    _analyticsPeriod.value = period
    val days = when (period) {
      "30 days" -> 30
      "90 days" -> 90
      else -> 7
    }
    generateAnalytics(days)
  }

  private fun generateAnalytics(days: Int) {
    val dateList = DateUtils.getLastNDaysIso(days)
    val points = dateList.mapIndexed { index, iso ->
      val label = if (days <= 7) DateUtils.getDayOfWeekShort(iso) else DateUtils.formatShortDate(iso)
      val seed = (iso.hashCode() % 1000).let { if (it < 0) -it else it }
      val steps = 6000 + (seed % 6000)
      val water = 1800 + (seed % 1200)
      val sleep = 420 + (seed % 90)
      val score = 70 + (seed % 28)
      val screen = 120 + (seed % 140)
      DayAnalyticsPoint(
        dateIso = iso,
        dayLabel = label,
        steps = if (iso == todayIso) _manualSteps.value.coerceAtLeast(steps) else steps,
        waterMl = if (iso == todayIso) todayWaterTotal.value.coerceAtLeast(water) else water,
        sleepMinutes = if (iso == todayIso) _todaySleepMinutes.value else sleep,
        dailyScore = if (iso == todayIso) todayDailyScore.value.totalScore else score,
        tasksCompleted = 3 + (seed % 4),
        habitsCompleted = 4 + (seed % 3),
        screenTimeMinutes = screen
      )
    }
    _analyticsData.value = points
  }

  fun refreshScreenTime() {
    _screenTimeStats.value = UsageStatsHelper.getScreenTimeStats(
      getApplication(),
      userProfile.value?.screenTimeTargetMinutes ?: 180
    )
  }

  // --- ACTIONS ---

  fun completeOnboarding(
    name: String,
    age: Int,
    gender: String,
    heightCm: Int,
    weightKg: Int,
    stepTarget: Int,
    waterTargetMl: Int,
    sleepTargetMinutes: Int,
    wakeTime: String,
    sleepTime: String
  ) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfile()
      val updated = current.copy(
        name = name.ifBlank { "Rahul" },
        age = age,
        gender = gender,
        heightCm = heightCm,
        weightKg = weightKg,
        stepTarget = stepTarget,
        waterTargetMl = waterTargetMl,
        sleepTargetMinutes = sleepTargetMinutes,
        wakeTime = wakeTime,
        sleepTime = sleepTime,
        isOnboardingCompleted = true
      )
      repository.updateProfile(updated)
    }
  }

  fun updateProfile(profile: UserProfile) {
    viewModelScope.launch {
      repository.updateProfile(profile)
    }
  }

  fun addTask(
    title: String,
    notes: String,
    priority: String,
    dueDate: String = todayIso,
    dueTime: String = "",
    category: String = "Personal"
  ) {
    viewModelScope.launch {
      repository.insertTask(
        TaskItem(
          title = title.trim(),
          notes = notes.trim(),
          priority = priority,
          dueDate = dueDate,
          dueTime = dueTime,
          category = category
        )
      )
    }
  }

  fun toggleTask(task: TaskItem) {
    viewModelScope.launch {
      repository.toggleTaskComplete(task)
    }
  }

  fun deleteTask(task: TaskItem) {
    viewModelScope.launch {
      repository.deleteTask(task)
    }
  }

  fun addHabit(
    name: String,
    iconName: String,
    colorHex: String,
    frequency: String,
    reminderTime: String = "08:00 AM"
  ) {
    viewModelScope.launch {
      repository.insertHabit(
        HabitItem(
          name = name.trim(),
          iconName = iconName,
          colorHex = colorHex,
          frequency = frequency,
          reminderTime = reminderTime
        )
      )
    }
  }

  fun toggleHabit(habitId: Long, date: String = todayIso) {
    viewModelScope.launch {
      repository.toggleHabitCompletion(habitId, date)
    }
  }

  fun deleteHabit(habit: HabitItem) {
    viewModelScope.launch {
      repository.deleteHabit(habit)
    }
  }

  fun addWater(amountMl: Int) {
    viewModelScope.launch {
      repository.addWater(amountMl, todayIso)
    }
  }

  fun deleteWaterLog(id: Long) {
    viewModelScope.launch {
      repository.deleteWaterLog(id)
    }
  }

  fun setManualSteps(steps: Int) {
    _manualSteps.value = steps
  }

  fun logSleep(minutes: Int, bedtime: String, wakeTime: String, quality: String) {
    _todaySleepMinutes.value = minutes
    _sleepBedtime.value = bedtime
    _sleepWakeTime.value = wakeTime
    _sleepQuality.value = quality
  }

  fun addGoal(
    title: String,
    description: String,
    goalType: String,
    targetValue: Double,
    unit: String,
    startDate: String,
    endDate: String
  ) {
    viewModelScope.launch {
      repository.insertGoal(
        GoalItem(
          title = title.trim(),
          description = description.trim(),
          goalType = goalType,
          targetValue = targetValue,
          unit = unit,
          startDate = startDate,
          endDate = endDate
        )
      )
    }
  }

  fun updateGoalProgress(goal: GoalItem, newProgress: Double) {
    viewModelScope.launch {
      val isCompleted = newProgress >= goal.targetValue
      val updated = goal.copy(
        currentValue = newProgress,
        status = if (isCompleted) "Completed" else goal.status
      )
      repository.updateGoal(updated)
    }
  }

  fun deleteGoal(goal: GoalItem) {
    viewModelScope.launch {
      repository.deleteGoal(goal)
    }
  }

  fun joinChallenge(challenge: ChallengeItem) {
    viewModelScope.launch {
      val updated = challenge.copy(
        isJoined = true,
        startDate = todayIso,
        currentDay = 1
      )
      repository.updateChallenge(updated)
    }
  }

  fun advanceChallengeDay(challenge: ChallengeItem) {
    viewModelScope.launch {
      val nextDay = challenge.currentDay + 1
      val isDone = nextDay > challenge.durationDays
      val updated = challenge.copy(
        currentDay = nextDay.coerceAtMost(challenge.durationDays),
        streak = challenge.streak + 1,
        isCompleted = isDone
      )
      repository.updateChallenge(updated)
      if (isDone) {
        repository.unlockAchievementDirect("challenge_completed")
      }
    }
  }

  fun selectCalendarDate(date: String) {
    _selectedCalendarDate.value = date
    loadCalendarDay(date)
  }

  private fun loadCalendarDay(date: String) {
    viewModelScope.launch {
      val targetSteps = userProfile.value?.stepTarget ?: 10000
      val targetWater = userProfile.value?.waterTargetMl ?: 2500

      // If today, use live stats
      if (date == todayIso) {
        val tasks = todayTasks.value
        val habits = habitsWithStatus.value
        _calendarSummary.value = CalendarDaySummary(
          dateIso = date,
          displayDate = DateUtils.formatDisplayDate(date),
          tasksCompleted = tasks.count { it.isCompleted },
          tasksTotal = tasks.size,
          habitsCompleted = habits.count { it.isCompletedToday },
          habitsTotal = habits.size,
          waterMl = todayWaterTotal.value,
          waterTargetMl = targetWater,
          steps = _manualSteps.value,
          stepTarget = targetSteps,
          sleepMinutes = _todaySleepMinutes.value,
          dailyScore = todayDailyScore.value.totalScore
        )
      } else {
        // Deterministic realistic historical data derived from date hash
        val seed = (date.hashCode() % 1000).let { if (it < 0) -it else it }
        val steps = 7000 + (seed % 4500)
        val water = 2000 + (seed % 800)
        val sleep = 420 + (seed % 60)
        val score = 75 + (seed % 20)
        _calendarSummary.value = CalendarDaySummary(
          dateIso = date,
          displayDate = DateUtils.formatDisplayDate(date),
          tasksCompleted = 4,
          tasksTotal = 5,
          habitsCompleted = 5,
          habitsTotal = 6,
          waterMl = water,
          waterTargetMl = targetWater,
          steps = steps,
          stepTarget = targetSteps,
          sleepMinutes = sleep,
          dailyScore = score
        )
      }
    }
  }

  fun clearAllHistory() {
    viewModelScope.launch {
      repository.clearHistory()
      generateAnalytics(7)
    }
  }

  fun resetAllData() {
    viewModelScope.launch {
      repository.resetAllData()
      _manualSteps.value = 0
      generateAnalytics(7)
    }
  }

  override fun onCleared() {
    super.onCleared()
    sensorManager.stopListening()
  }
}
