package com.example.ui.screens.details

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.HealthAndSensorManager
import com.example.ui.components.BarChartItem
import com.example.ui.components.LogSleepDialog
import com.example.ui.components.MiniBarChart
import com.example.ui.theme.AccentSleep
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun SleepDetailScreen(
  viewModel: LifeOsViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val sleepMinutes by viewModel.todaySleepMinutes.collectAsState()
  val bedtime by viewModel.sleepBedtime.collectAsState()
  val wakeTime by viewModel.sleepWakeTime.collectAsState()
  val sleepQuality by viewModel.sleepQuality.collectAsState()
  val analyticsData by viewModel.analyticsData.collectAsState()
  val context = LocalContext.current

  val sensorManager = remember { HealthAndSensorManager(context) }
  var showLogDialog by remember { mutableStateOf(false) }

  val targetMinutes = userProfile?.sleepTargetMinutes ?: 480
  val hours = sleepMinutes / 60
  val minutes = sleepMinutes % 60
  val progress = (sleepMinutes.toFloat() / targetMinutes).coerceIn(0f, 1f)

  val chartItems = analyticsData.takeLast(7).map {
    BarChartItem(
      label = it.dayLabel,
      value = (it.sleepMinutes / 60f),
      isHighlight = it.dateIso == viewModel.todayIso
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Bar
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Sleep Recovery 😴",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Hero Sleep Card
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "LAST NIGHT'S REST",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = AccentSleep
          )

          Spacer(modifier = Modifier.height(14.dp))

          Surface(
            shape = CircleShape,
            color = AccentSleep.copy(alpha = 0.15f),
            modifier = Modifier.size(68.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Filled.Bedtime, contentDescription = null, tint = AccentSleep, modifier = Modifier.size(36.dp))
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "${hours}h ${minutes}m",
            fontSize = 36.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Text(
            text = "Target: ${targetMinutes / 60} hours • Quality: $sleepQuality",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(16.dp))

          LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = AccentSleep,
            trackColor = AccentSleep.copy(alpha = 0.2f),
            strokeCap = StrokeCap.Round
          )

          Spacer(modifier = Modifier.height(20.dp))

          // Bedtime and Wake time tiles
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            TimeTile(Icons.Filled.Bedtime, bedtime, "Bedtime")
            TimeTile(Icons.Filled.WbSunny, wakeTime, "Wake Time")
          }
        }
      }
    }

    // Action buttons: Log sleep or Health Connect
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = { showLogDialog = true },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text("Log / Edit Sleep")
        }

        OutlinedButton(
          onClick = { sensorManager.openHealthConnectSettings(context) },
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Health Connect")
        }
      }
    }

    // 7-Day Sleep Duration Chart
    item {
      MiniBarChart(
        title = "7-Day Sleep Duration",
        subtitle = "Hours slept per night",
        items = chartItems,
        targetValue = (targetMinutes / 60f),
        barColor = AccentSleep,
        unit = "hrs"
      )
    }

    // Sleep consistency insight
    item {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("💡 Sleep Consistency Insight", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Your average wake-up time is within 15 minutes of your target. Regular sleep schedules drastically improve your deep sleep cycles and daily lifestyle score.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 20.sp
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }

  if (showLogDialog) {
    LogSleepDialog(
      onDismiss = { showLogDialog = false },
      onConfirm = { mins, bed, wake, qual ->
        viewModel.logSleep(mins, bed, wake, qual)
        showLogDialog = false
      }
    )
  }
}

@Composable
private fun TimeTile(icon: androidx.compose.ui.graphics.vector.ImageVector, time: String, label: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(icon, contentDescription = null, tint = AccentSleep, modifier = Modifier.size(18.dp))
    Spacer(modifier = Modifier.width(6.dp))
    Column {
      Text(time, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}
