package com.example.ui.screens.habits

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentStreak
import com.example.ui.viewmodel.HabitUiModel
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun HabitsScreen(
  viewModel: LifeOsViewModel,
  onAddHabitClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val habits by viewModel.habitsWithStatus.collectAsState()
  val completedToday = habits.count { it.isCompletedToday }
  val avgStreak = if (habits.isNotEmpty()) (habits.sumOf { it.habit.currentStreak } / habits.size) else 0

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(12.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Daily Habits",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.onBackground
            )
            Text(
              text = "$completedToday of ${habits.size} done today • Avg streak: $avgStreak days",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Habits List
      if (habits.isEmpty()) {
        item {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(36.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("No habits set up yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
              Spacer(modifier = Modifier.height(6.dp))
              Text("Tap + to build your first routine.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      } else {
        items(habits, key = { it.habit.id }) { habitModel ->
          HabitDetailCard(
            habitModel = habitModel,
            onToggle = { viewModel.toggleHabit(habitModel.habit.id) },
            onDelete = { viewModel.deleteHabit(habitModel.habit) }
          )
        }
      }

      item {
        Spacer(modifier = Modifier.height(84.dp))
      }
    }

    // FAB Add Habit
    FloatingActionButton(
      onClick = onAddHabitClick,
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = MaterialTheme.colorScheme.onPrimary,
      shape = RoundedCornerShape(18.dp),
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 20.dp, bottom = 80.dp)
        .testTag("fab_add_habit")
    ) {
      Icon(Icons.Filled.Add, contentDescription = "Add Habit")
    }
  }
}

@Composable
private fun HabitDetailCard(
  habitModel: HabitUiModel,
  onToggle: () -> Unit,
  onDelete: () -> Unit
) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val cardBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)

  val habit = habitModel.habit
  val habitColor = try {
    Color(android.graphics.Color.parseColor(habit.colorHex))
  } catch (e: Exception) {
    MaterialTheme.colorScheme.primary
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = habitColor.copy(alpha = 0.15f),
            modifier = Modifier.size(42.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = habitColor, modifier = Modifier.size(22.dp))
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column {
            Text(
              text = habit.name,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "${habit.frequency} • Reminder: ${habit.reminderTime}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Tap to complete button
        Surface(
          shape = CircleShape,
          color = if (habitModel.isCompletedToday) habitColor else MaterialTheme.colorScheme.surface,
          modifier = Modifier
            .size(40.dp)
            .clickable { onToggle() }
            .testTag("habit_toggle_${habit.id}")
        ) {
          Box(contentAlignment = Alignment.Center) {
            if (habitModel.isCompletedToday) {
              Icon(Icons.Filled.Check, contentDescription = "Completed Today", tint = Color.White, modifier = Modifier.size(24.dp))
            } else {
              Text("Log", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Streaks and Stats Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = AccentStreak.copy(alpha = 0.15f)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Filled.Whatshot, contentDescription = null, tint = AccentStreak, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${habit.currentStreak} day streak",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = AccentStreak
              )
            }
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = "Best: ${habit.bestStreak}d",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Rate: ${habitModel.completionRate}%",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
          )

          Spacer(modifier = Modifier.width(4.dp))

          IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete Habit", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(16.dp))
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      LinearProgressIndicator(
        progress = { habitModel.completionRate / 100f },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = habitColor,
        trackColor = habitColor.copy(alpha = 0.2f),
        strokeCap = StrokeCap.Round
      )
    }
  }
}
