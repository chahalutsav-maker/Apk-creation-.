package com.example.ui.screens.details

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BarChartItem
import com.example.ui.components.MiniBarChart
import com.example.ui.theme.AccentSleep
import com.example.ui.theme.AccentSteps
import com.example.ui.theme.AccentWater
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun AnalyticsScreen(
  viewModel: LifeOsViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val period by viewModel.analyticsPeriod.collectAsState()
  val analyticsData by viewModel.analyticsData.collectAsState()
  val consistencyStats by viewModel.consistencyStats.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()

  val periods = listOf("7 days", "30 days", "90 days")

  val scoreChartItems = analyticsData.takeLast(7).map {
    BarChartItem(label = it.dayLabel, value = it.dailyScore.toFloat(), isHighlight = it.dateIso == viewModel.todayIso)
  }

  val stepsChartItems = analyticsData.takeLast(7).map {
    BarChartItem(label = it.dayLabel, value = it.steps.toFloat(), isHighlight = it.dateIso == viewModel.todayIso)
  }

  val waterChartItems = analyticsData.takeLast(7).map {
    BarChartItem(label = it.dayLabel, value = it.waterMl.toFloat(), isHighlight = it.dateIso == viewModel.todayIso)
  }

  val habitsChartItems = analyticsData.takeLast(7).map {
    BarChartItem(label = it.dayLabel, value = it.habitsCompleted.toFloat(), isHighlight = it.dateIso == viewModel.todayIso)
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Bar
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Analytics & Trends 📊",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Consistency Hero Card
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "OVERALL CONSISTENCY",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = MaterialTheme.colorScheme.primary
          )

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "${consistencyStats.consistencyPercentage}%",
            fontSize = 44.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Text(
            text = "Active streak: ${consistencyStats.currentStreak} days • Best: ${consistencyStats.bestStreak} days",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // Filter Chips (7d, 30d, 90d)
    item {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        periods.forEach { p ->
          FilterChip(
            selected = period == p,
            onClick = { viewModel.setAnalyticsPeriod(p) },
            label = { Text(p) },
            modifier = Modifier.testTag("analytics_period_$p")
          )
        }
      }
    }

    // Smart Insights Section
    item {
      Text(
        text = "SMART LIFESTYLE INSIGHTS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        InsightCard("Your average daily steps increased by 18% over the last week.", Color(0xFF10B981))
        InsightCard("You sleep 45 minutes longer on nights when screen time is under 2.5 hours.", AccentSleep)
        InsightCard("Your most consistent habit is 'Exercise & Stretching' with an active 12-day streak.", Color(0xFFF59E0B))
        InsightCard("Task completion rate peaks at 94% on Tuesdays and Thursdays.", MaterialTheme.colorScheme.primary)
      }
    }

    // Chart 1: Daily Score Trend
    item {
      MiniBarChart(
        title = "Daily Lifestyle Score Trend",
        subtitle = "Composite score across steps, water, sleep, tasks, habits",
        items = scoreChartItems,
        targetValue = 85f,
        barColor = MaterialTheme.colorScheme.primary,
        unit = "pts"
      )
    }

    // Chart 2: Step Trend
    item {
      MiniBarChart(
        title = "Steps Trend",
        subtitle = "Daily step volumes",
        items = stepsChartItems,
        targetValue = (userProfile?.stepTarget ?: 10000).toFloat(),
        barColor = AccentSteps,
        unit = "steps"
      )
    }

    // Chart 3: Water Trend
    item {
      MiniBarChart(
        title = "Hydration Trend",
        subtitle = "Daily water consumption in milliliters",
        items = waterChartItems,
        targetValue = (userProfile?.waterTargetMl ?: 2500).toFloat(),
        barColor = AccentWater,
        unit = "ml"
      )
    }

    // Chart 4: Habit Completions
    item {
      MiniBarChart(
        title = "Habits Completed per Day",
        subtitle = "Total routines checked off daily",
        items = habitsChartItems,
        targetValue = 6f,
        barColor = MaterialTheme.colorScheme.secondary,
        unit = "habits"
      )
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}

@Composable
private fun InsightCard(text: String, accentColor: Color) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(shape = CircleShape, color = accentColor.copy(alpha = 0.15f), modifier = Modifier.size(36.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurface,
        lineHeight = 20.sp
      )
    }
  }
}
