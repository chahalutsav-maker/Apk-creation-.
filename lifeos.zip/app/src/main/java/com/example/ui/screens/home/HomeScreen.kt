package com.example.ui.screens.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TaskItem
import com.example.service.HealthAndSensorManager
import com.example.ui.components.DailyScoreCard
import com.example.ui.components.DailySummaryDialog
import com.example.ui.theme.AccentScreenTime
import com.example.ui.theme.AccentScreenTimeBg
import com.example.ui.theme.AccentSleep
import com.example.ui.theme.AccentSleepBg
import com.example.ui.theme.AccentSteps
import com.example.ui.theme.AccentStepsBg
import com.example.ui.theme.AccentStreak
import com.example.ui.theme.AccentWater
import com.example.ui.theme.AccentWaterBg
import com.example.ui.viewmodel.HabitUiModel
import com.example.ui.viewmodel.LifeOsViewModel
import com.example.util.DateUtils

@Composable
fun HomeScreen(
  viewModel: LifeOsViewModel,
  onNavigateToWater: () -> Unit,
  onNavigateToSteps: () -> Unit,
  onNavigateToSleep: () -> Unit,
  onNavigateToScreenTime: () -> Unit,
  onNavigateToTasks: () -> Unit,
  onNavigateToHabits: () -> Unit,
  onAddTaskClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val dailyScore by viewModel.todayDailyScore.collectAsState()
  val tasks by viewModel.todayTasks.collectAsState()
  val habits by viewModel.habitsWithStatus.collectAsState()
  val waterTotal by viewModel.todayWaterTotal.collectAsState()
  val steps by viewModel.manualSteps.collectAsState()
  val sleepMinutes by viewModel.todaySleepMinutes.collectAsState()
  val sleepQuality by viewModel.sleepQuality.collectAsState()
  val screenTimeStats by viewModel.screenTimeStats.collectAsState()

  var showSummaryDialog by remember { mutableStateOf(false) }

  val targetSteps = userProfile?.stepTarget ?: 10000
  val targetWater = userProfile?.waterTargetMl ?: 2500
  val targetSleep = userProfile?.sleepTargetMinutes ?: 480
  val userName = userProfile?.name ?: "Rahul"

  val completedTasksCount = tasks.count { it.isCompleted }
  val completedHabitsCount = habits.count { it.isCompletedToday }

  val isDark = MaterialTheme.colorScheme.background.red < 0.2f

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // 1. PROFESSIONAL POLISH HEADER (Rounded Bottom Surface with Shadow)
    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp),
      color = MaterialTheme.colorScheme.surface,
      border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)),
      shadowElevation = 2.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 20.dp, vertical = 16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = DateUtils.formatDisplayDate(DateUtils.todayIso()),
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "${DateUtils.getGreeting()}, $userName 👋",
              fontSize = 22.sp,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          Surface(
            shape = CircleShape,
            color = if (isDark) Color(0xFF1E3A8A) else Color(0xFFDBEAFE),
            border = BorderStroke(2.dp, if (isDark) Color(0xFF334155) else Color.White),
            shadowElevation = 2.dp,
            modifier = Modifier
              .size(46.dp)
              .clickable { showSummaryDialog = true }
              .testTag("home_user_avatar")
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                text = (userName.firstOrNull() ?: 'R').uppercase().toString(),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) Color(0xFF93C5FD) else Color(0xFF2563EB)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Daily Lifestyle Score banner card
        DailyScoreCard(
          scoreResult = dailyScore,
          onClick = { showSummaryDialog = true },
          modifier = Modifier.testTag("home_daily_score_card")
        )
      }
    }

    // 2. SCROLLABLE CONTENT BODY
    LazyColumn(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        Spacer(modifier = Modifier.height(4.dp))
      }

      // 2x2 METRICS GRID
      item {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          // Row 1: Steps & Water
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Steps Card
            val stepDistance = HealthAndSensorManager.calculateDistanceKm(steps, userProfile?.heightCm ?: 175)
            val stepProgress = (steps.toFloat() / targetSteps).coerceIn(0f, 1f)

            MetricCard(
              title = "Steps",
              value = String.format("%,d", steps),
              subValue = "Goal: ${String.format("%,d", targetSteps)}",
              progress = stepProgress,
              badgeText = "${(stepProgress * 100).toInt()}%",
              icon = Icons.Filled.DirectionsWalk,
              accentColor = AccentSteps,
              iconBgColor = AccentStepsBg,
              badgeColor = AccentSteps,
              badgeBg = if (isDark) Color(0xFF431407) else Color(0xFFFFF7ED),
              onClick = onNavigateToSteps,
              modifier = Modifier
                .weight(1f)
                .testTag("metric_card_steps")
            )

            // Water Card
            val waterProgress = (waterTotal.toFloat() / targetWater).coerceIn(0f, 1f)
            MetricCard(
              title = "Water",
              value = "${String.format("%,d", waterTotal)} ml",
              subValue = "Goal: ${String.format("%,d", targetWater)} ml",
              progress = waterProgress,
              badgeText = "",
              icon = Icons.Filled.LocalDrink,
              accentColor = AccentWater,
              iconBgColor = AccentWaterBg,
              onClick = onNavigateToWater,
              extraAction = {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFF2563EB),
                  modifier = Modifier
                    .size(26.dp)
                    .clickable { viewModel.addWater(250) }
                    .testTag("quick_water_add_button")
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(
                      imageVector = Icons.Filled.Add,
                      contentDescription = "Quick Add Water",
                      tint = Color.White,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              },
              modifier = Modifier
                .weight(1f)
                .testTag("metric_card_water")
            )
          }

          // Row 2: Sleep & Screen Time
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            // Sleep Card
            val sleepHrs = sleepMinutes / 60
            val sleepMins = sleepMinutes % 60
            val sleepProgress = (sleepMinutes.toFloat() / targetSleep).coerceIn(0f, 1f)
            MetricCard(
              title = "Sleep",
              value = "${sleepHrs}h ${sleepMins}m",
              subValue = if (sleepQuality.contains("Good", ignoreCase = true) || sleepQuality.contains("Great", ignoreCase = true)) "Good Quality" else sleepQuality,
              progress = sleepProgress,
              badgeText = "${targetSleep / 60}h",
              icon = Icons.Filled.Bedtime,
              accentColor = AccentSleep,
              iconBgColor = AccentSleepBg,
              badgeColor = AccentSleep,
              badgeBg = if (isDark) Color(0xFF1E1B4B) else Color(0xFFEEF2FF),
              onClick = onNavigateToSleep,
              modifier = Modifier
                .weight(1f)
                .testTag("metric_card_sleep")
            )

            // Screen Time Card
            val diff = screenTimeStats.differenceMinutes
            val diffText = if (diff >= 0) "+${diff}m" else "${diff}m"
            val isExceed = screenTimeStats.isExceedingTarget
            MetricCard(
              title = "Screen",
              value = screenTimeStats.todayFormatted,
              subValue = "Avg: 2h 20m",
              progress = (screenTimeStats.todayMillis / (180 * 60 * 1000f)).coerceIn(0f, 1f),
              badgeText = if (screenTimeStats.isPermissionGranted) diffText else "Sync",
              icon = Icons.Filled.PhoneAndroid,
              accentColor = if (isExceed) AccentScreenTime else Color(0xFFEA580C),
              iconBgColor = AccentScreenTimeBg,
              badgeColor = if (diff > 0) AccentScreenTime else Color(0xFF059669),
              badgeBg = if (diff > 0) (if (isDark) Color(0xFF450A0A) else Color(0xFFFEF2F2)) else (if (isDark) Color(0xFF064E3B) else Color(0xFFECFDF5)),
              onClick = onNavigateToScreenTime,
              modifier = Modifier
                .weight(1f)
                .testTag("metric_card_screentime")
            )
          }
        }
      }

      // TODAY'S FOCUS HERO CARD (Dark slate 900 card from Professional Polish HTML)
      item {
        TodaysFocusCard(
          tasks = tasks,
          completedCount = completedTasksCount,
          onToggleTask = { viewModel.toggleTask(it) },
          onAddTask = onAddTaskClick,
          modifier = Modifier.testTag("todays_focus_hero_card")
        )
      }

      // TODAY'S TASKS SECTION
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Today's Tasks",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$completedTasksCount/${tasks.size} completed",
              style = MaterialTheme.typography.bodySmall,
              color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onNavigateToTasks) {
              Text("See All", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(
              onClick = onAddTaskClick,
              modifier = Modifier.size(32.dp)
            ) {
              Icon(Icons.Filled.Add, contentDescription = "Add Task", tint = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }

      if (tasks.isEmpty()) {
        item {
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "No tasks scheduled for today",
                style = MaterialTheme.typography.bodyMedium,
                color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
              )
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(onClick = onAddTaskClick) {
                Text("Add a task")
              }
            }
          }
        }
      } else {
        items(tasks.take(4)) { task ->
          HomeTaskCard(
            task = task,
            onToggle = { viewModel.toggleTask(task) }
          )
        }
      }

      // TODAY'S HABITS SECTION
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "Today's Habits",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$completedHabitsCount/${habits.size} completed",
              style = MaterialTheme.typography.bodySmall,
              color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
            )
          }

          TextButton(onClick = onNavigateToHabits) {
            Text("Manage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      items(habits.take(5)) { habitItem ->
        HomeHabitCard(
          habitModel = habitItem,
          onToggle = { viewModel.toggleHabit(habitItem.habit.id) }
        )
      }

      item {
        Spacer(modifier = Modifier.height(84.dp)) // Space for bottom navigation & FAB
      }
    }
  }

  // Daily Summary Dialog
  if (showSummaryDialog) {
    DailySummaryDialog(
      onDismiss = { showSummaryDialog = false },
      steps = steps,
      stepTarget = targetSteps,
      waterMl = waterTotal,
      waterTargetMl = targetWater,
      sleepMinutes = sleepMinutes,
      tasksCompleted = completedTasksCount,
      tasksTotal = tasks.size,
      habitsCompleted = completedHabitsCount,
      habitsTotal = habits.size,
      screenTimeFormatted = screenTimeStats.todayFormatted,
      dailyScore = dailyScore.totalScore,
      motivationalMessage = dailyScore.message
    )
  }
}

// METRIC CARD COMPONENT - PROFESSIONAL POLISH DESIGN
@Composable
private fun MetricCard(
  title: String,
  value: String,
  subValue: String,
  progress: Float,
  badgeText: String,
  icon: ImageVector,
  accentColor: Color,
  iconBgColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  badgeColor: Color = accentColor,
  badgeBg: Color = iconBgColor,
  extraAction: (@Composable () -> Unit)? = null
) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val cardBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)

  Card(
    modifier = modifier.clickable { onClick() },
    shape = RoundedCornerShape(24.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = iconBgColor,
          modifier = Modifier.size(34.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
          }
        }

        if (extraAction != null) {
          extraAction()
        } else if (badgeText.isNotBlank()) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = badgeBg
          ) {
            Text(
              text = badgeText,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = badgeColor,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = title.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.1.sp,
        color = if (isDark) Color(0xFF94A3B8) else Color(0xFF94A3B8)
      )

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = value,
        fontSize = 19.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )

      Text(
        text = subValue,
        fontSize = 10.sp,
        fontWeight = FontWeight.Normal,
        color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
      )

      Spacer(modifier = Modifier.height(8.dp))

      LinearProgressIndicator(
        progress = { progress },
        modifier = Modifier
          .fillMaxWidth()
          .height(4.dp)
          .clip(RoundedCornerShape(2.dp)),
        color = accentColor,
        trackColor = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9),
        strokeCap = StrokeCap.Round
      )
    }
  }
}

// TODAY'S FOCUS HERO CARD (STANDOUT SLATE 900 COMPONENT)
@Composable
private fun TodaysFocusCard(
  tasks: List<TaskItem>,
  completedCount: Int,
  onToggleTask: (TaskItem) -> Unit,
  onAddTask: () -> Unit,
  modifier: Modifier = Modifier
) {
  val focusTask = tasks.firstOrNull { !it.isCompleted } ?: tasks.firstOrNull()

  Card(
    shape = RoundedCornerShape(28.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), // Slate 900
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    modifier = modifier.fillMaxWidth()
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp)
    ) {
      // Decorative blue glow
      Box(
        modifier = Modifier
          .size(90.dp)
          .align(Alignment.TopEnd)
          .background(
            Brush.radialGradient(
              colors = listOf(Color(0xFF2563EB).copy(alpha = 0.35f), Color.Transparent)
            ),
            shape = CircleShape
          )
      )

      Column {
        Text(
          text = "Today's Focus",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (focusTask != null) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onToggleTask(focusTask) }
          ) {
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = if (focusTask.isCompleted) Color(0xFF2563EB) else Color.Transparent,
              border = BorderStroke(
                1.5.dp,
                if (focusTask.isCompleted) Color(0xFF2563EB) else Color.White.copy(alpha = 0.4f)
              ),
              modifier = Modifier.size(20.dp)
            ) {
              if (focusTask.isCompleted) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                }
              }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
              text = focusTask.title,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = Color.White.copy(alpha = 0.95f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f)
            )
          }
        } else {
          Text(
            text = "No focus task set. Add one below!",
            fontSize = 13.sp,
            color = Color.White.copy(alpha = 0.7f)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "$completedCount / ${tasks.size} TASKS COMPLETED",
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.2.sp,
          color = Color(0xFF60A5FA)
        )
      }
    }
  }
}

// HOME TASK CARD - PROFESSIONAL POLISH
@Composable
private fun HomeTaskCard(task: TaskItem, onToggle: () -> Unit) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val cardBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)

  val priorityColor = when (task.priority) {
    "High" -> Color(0xFFDC2626)
    "Medium" -> Color(0xFFD97706)
    else -> Color(0xFF2563EB)
  }
  val priorityBg = when (task.priority) {
    "High" -> if (isDark) Color(0xFF450A0A) else Color(0xFFFEE2E2)
    "Medium" -> if (isDark) Color(0xFF451A03) else Color(0xFFFEF3C7)
    else -> if (isDark) Color(0xFF172554) else Color(0xFFDBEAFE)
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) {
        MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    border = BorderStroke(1.dp, cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = task.isCompleted,
        onCheckedChange = { onToggle() },
        colors = CheckboxDefaults.colors(
          checkedColor = MaterialTheme.colorScheme.primary,
          uncheckedColor = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
        )
      )

      Spacer(modifier = Modifier.width(6.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          fontSize = 14.sp,
          fontWeight = if (task.isCompleted) FontWeight.Normal else FontWeight.SemiBold,
          color = if (task.isCompleted) {
            if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
          } else {
            MaterialTheme.colorScheme.onSurface
          }
        )
        if (task.dueTime.isNotBlank() || task.category.isNotBlank()) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (task.dueTime.isNotBlank()) {
              Text(
                text = task.dueTime,
                fontSize = 11.sp,
                color = if (isDark) Color(0xFF64748B) else Color(0xFF64748B)
              )
              Text(" • ", fontSize = 11.sp, color = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8))
            }
            Text(
              text = task.category,
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = priorityBg
      ) {
        Text(
          text = task.priority,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = priorityColor,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
      }
    }
  }
}

// HOME HABIT CARD - PROFESSIONAL POLISH
@Composable
private fun HomeHabitCard(habitModel: HabitUiModel, onToggle: () -> Unit) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val cardBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)
  val habit = habitModel.habit
  val habitColor = try {
    Color(android.graphics.Color.parseColor(habit.colorHex))
  } catch (e: Exception) {
    MaterialTheme.colorScheme.primary
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, cardBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = habitColor.copy(alpha = 0.15f),
          modifier = Modifier.size(38.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = habitColor, modifier = Modifier.size(20.dp))
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Text(
            text = habit.name,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Whatshot, contentDescription = null, tint = AccentStreak, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = "${habit.currentStreak} day streak (Best: ${habit.bestStreak})",
              fontSize = 11.sp,
              color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
            )
          }
        }
      }

      Surface(
        shape = CircleShape,
        color = if (habitModel.isCompletedToday) Color(0xFF2563EB) else Color.Transparent,
        border = BorderStroke(
          1.5.dp,
          if (habitModel.isCompletedToday) Color(0xFF2563EB) else if (isDark) Color(0xFF64748B) else Color(0xFFCBD5E1)
        ),
        modifier = Modifier
          .size(32.dp)
          .clickable { onToggle() }
      ) {
        Box(contentAlignment = Alignment.Center) {
          if (habitModel.isCompletedToday) {
            Icon(Icons.Filled.Check, contentDescription = "Completed", tint = Color.White, modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}

