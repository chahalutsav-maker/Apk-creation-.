package com.example.ui.screens.details

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChallengeItem
import com.example.ui.theme.AccentStreak
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun ChallengesScreen(
  viewModel: LifeOsViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val challenges by viewModel.allChallenges.collectAsState()
  val joinedCount = challenges.count { it.isJoined }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Bar
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Life Challenges 🏆",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Hero Badge Header
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text("Active Disciplines", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("$joinedCount active challenge protocols", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Surface(shape = CircleShape, color = Color(0xFFEAB308), modifier = Modifier.size(44.dp)) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
          }
        }
      }
    }

    items(challenges, key = { it.id }) { challenge ->
      ChallengeCardItem(
        challenge = challenge,
        onJoin = { viewModel.joinChallenge(challenge) },
        onAdvanceDay = { viewModel.advanceChallengeDay(challenge) }
      )
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }
}

@Composable
private fun ChallengeCardItem(
  challenge: ChallengeItem,
  onJoin: () -> Unit,
  onAdvanceDay: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (challenge.isJoined) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
      else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    ),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(challenge.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text(challenge.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFFEAB308).copy(alpha = 0.15f)
        ) {
          Text(
            text = "${challenge.durationDays} Days",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFEAB308),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "Daily Requirement: ${challenge.dailyRequirement}",
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
      )

      if (challenge.isJoined) {
        Spacer(modifier = Modifier.height(12.dp))

        LinearProgressIndicator(
          progress = { challenge.progressPercentage / 100f },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = Color(0xFFEAB308),
          trackColor = Color(0xFFEAB308).copy(alpha = 0.2f),
          strokeCap = StrokeCap.Round
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Day ${challenge.currentDay} of ${challenge.durationDays}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(Icons.Filled.Whatshot, contentDescription = null, tint = AccentStreak, modifier = Modifier.size(14.dp))
            Text("${challenge.streak}d streak", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          if (!challenge.isCompleted) {
            Button(
              onClick = onAdvanceDay,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Text("Complete Today", fontSize = 11.sp)
            }
          } else {
            Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF10B981).copy(alpha = 0.15f)) {
              Text("COMPLETED 🎉", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            }
          }
        }
      } else {
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
          onClick = onJoin,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("Join Challenge")
        }
      }
    }
  }
}
