package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors - Professional Polish Theme
val PrimaryLight = Color(0xFF2563EB) // Tailwind Blue 600
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE) // Tailwind Blue 100
val OnPrimaryContainerLight = Color(0xFF1D4ED8) // Tailwind Blue 700

val SecondaryLight = Color(0xFF059669) // Emerald 600
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD1FAE5) // Emerald 100
val OnSecondaryContainerLight = Color(0xFF047857)

val TertiaryLight = Color(0xFF4F46E5) // Indigo 600
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFE0E7FF) // Indigo 100
val OnTertiaryContainerLight = Color(0xFF3730A3)

val BackgroundLight = Color(0xFFF3F4F6) // Exact Design HTML background #F3F4F6
val OnBackgroundLight = Color(0xFF0F172A) // Slate 900
val SurfaceLight = Color(0xFFFFFFFF) // Pure Crisp White
val OnSurfaceLight = Color(0xFF0F172A) // Slate 900
val SurfaceVariantLight = Color(0xFFF8FAFC) // Slate 50
val OnSurfaceVariantLight = Color(0xFF64748B) // Slate 500
val OutlineLight = Color(0xFFE2E8F0) // Slate 200

// Dark Scheme Colors
val PrimaryDark = Color(0xFF60A5FA) // Blue 400
val OnPrimaryDark = Color(0xFF0F172A)
val PrimaryContainerDark = Color(0xFF1E3A8A) // Blue 900
val OnPrimaryContainerDark = Color(0xFFDBEAFE)

val SecondaryDark = Color(0xFF34D399) // Emerald 400
val OnSecondaryDark = Color(0xFF064E3B)
val SecondaryContainerDark = Color(0xFF065F46)
val OnSecondaryContainerDark = Color(0xFFA7F3D0)

val TertiaryDark = Color(0xFF818CF8) // Indigo 400
val OnTertiaryDark = Color(0xFF1E1B4B)
val TertiaryContainerDark = Color(0xFF312E81)
val OnTertiaryContainerDark = Color(0xFFE0E7FF)

val BackgroundDark = Color(0xFF0B0F17) // Slate 950
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF131D2D) // Elevated Dark Slate
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1E293B) // Slate 800
val OnSurfaceVariantDark = Color(0xFF94A3B8) // Slate 400
val OutlineDark = Color(0xFF334155) // Slate 700

// Domain Accent Colors - Matching Professional Polish HTML
val AccentWater = Color(0xFF2563EB) // Blue 600
val AccentWaterBg = Color(0xFFDBEAFE) // Blue 100
val AccentSteps = Color(0xFFEA580C) // Orange 600
val AccentStepsBg = Color(0xFFFFEDD5) // Orange 100
val AccentSleep = Color(0xFF4F46E5) // Indigo 600
val AccentSleepBg = Color(0xFFE0E7FF) // Indigo 100
val AccentScreenTime = Color(0xFFDC2626) // Red 600
val AccentScreenTimeBg = Color(0xFFFEE2E2) // Red 100
val AccentStreak = Color(0xFFEA580C)
val AccentGold = Color(0xFFEAB308)
val AccentPurple = Color(0xFF7C3AED)
val AccentRose = Color(0xFFE11D48)
val AccentEmerald = Color(0xFF10B981)

