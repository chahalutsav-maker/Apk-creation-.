package com.example.ui.screens.profile

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.service.HealthAndSensorManager
import com.example.service.NotificationHelper
import com.example.service.UsageStatsHelper
import com.example.ui.theme.AccentStreak
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun ProfileScreen(
  viewModel: LifeOsViewModel,
  onNavigateToGoals: () -> Unit,
  onNavigateToChallenges: () -> Unit,
  onNavigateToAnalytics: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val consistencyStats by viewModel.consistencyStats.collectAsState()
  val context = LocalContext.current

  var showEditProfileDialog by remember { mutableStateOf(false) }
  var showResetDialog by remember { mutableStateOf(false) }

  val sensorManager = remember { HealthAndSensorManager(context) }
  val hasActivity = sensorManager.hasActivityRecognitionPermission()
  val hasNotif = NotificationHelper.hasNotificationPermission(context)
  val hasUsage = UsageStatsHelper.hasUsageStatsPermission(context)

  val profile = userProfile ?: UserProfile()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header & User Card
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Text(
        text = "Profile & Settings",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground
      )
    }

    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(56.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                }
              }

              Spacer(modifier = Modifier.width(14.dp))

              Column {
                Text(
                  text = profile.name,
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "${profile.age} yrs • ${profile.heightCm} cm • ${profile.weightKg} kg",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(
              onClick = { showEditProfileDialog = true },
              modifier = Modifier.testTag("edit_profile_button")
            ) {
              Icon(Icons.Filled.Edit, contentDescription = "Edit Profile", tint = MaterialTheme.colorScheme.primary)
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Consistency & Streaks Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            StatPill(
              title = "Consistency",
              value = "${consistencyStats.consistencyPercentage}%",
              icon = Icons.Filled.Insights,
              color = MaterialTheme.colorScheme.primary
            )
            StatPill(
              title = "Streak",
              value = "${consistencyStats.currentStreak}d",
              icon = Icons.Filled.Whatshot,
              color = AccentStreak
            )
            StatPill(
              title = "Best",
              value = "${consistencyStats.bestStreak}d",
              icon = Icons.Filled.EmojiEvents,
              color = Color(0xFFEAB308)
            )
            StatPill(
              title = "Active",
              value = "${consistencyStats.daysActive}d",
              icon = Icons.Filled.Shield,
              color = Color(0xFF10B981)
            )
          }
        }
      }
    }

    // FEATURE SHORTCUTS (Goals, Challenges, Analytics)
    item {
      Text(
        text = "LIFESTYLE MODULES",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ShortcutRow(
          icon = Icons.Filled.Flag,
          title = "Goals & Milestones",
          subtitle = "Track targeted achievements across fitness & routines",
          color = MaterialTheme.colorScheme.primary,
          onClick = onNavigateToGoals,
          testTag = "shortcut_goals"
        )
        ShortcutRow(
          icon = Icons.Filled.EmojiEvents,
          title = "Challenges (30–90 Days)",
          subtitle = "10K Steps, Hydration Hero, 75-Day Hard Discipline",
          color = Color(0xFFEAB308),
          onClick = onNavigateToChallenges,
          testTag = "shortcut_challenges"
        )
        ShortcutRow(
          icon = Icons.Filled.Insights,
          title = "Analytics & Insights",
          subtitle = "7, 30, and 90-day progress curves and consistency stats",
          color = MaterialTheme.colorScheme.secondary,
          onClick = onNavigateToAnalytics,
          testTag = "shortcut_analytics"
        )
      }
    }

    // DAILY TARGETS SECTION
    item {
      Text(
        text = "DAILY TARGETS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          TargetRow("Steps Target", "${profile.stepTarget} steps")
          TargetRow("Water Target", "${profile.waterTargetMl} ml")
          TargetRow("Sleep Target", "${profile.sleepTargetMinutes / 60}h ${profile.sleepTargetMinutes % 60}m")
          TargetRow("Screen Time Target", "${profile.screenTimeTargetMinutes / 60}h")
          TargetRow("Preferred Wake Time", profile.wakeTime)
          TargetRow("Preferred Bedtime", profile.sleepTime)
        }
      }
    }

    // REMINDERS & NOTIFICATIONS
    item {
      Text(
        text = "REMINDERS & NOTIFICATIONS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ReminderToggleRow(
            title = "Water Reminders",
            checked = profile.waterReminders,
            onCheckedChange = { viewModel.updateProfile(profile.copy(waterReminders = it)) }
          )
          ReminderToggleRow(
            title = "Habit Reminders & Streaks",
            checked = profile.habitReminders,
            onCheckedChange = { viewModel.updateProfile(profile.copy(habitReminders = it)) }
          )
          ReminderToggleRow(
            title = "Task Due Reminders",
            checked = profile.taskReminders,
            onCheckedChange = { viewModel.updateProfile(profile.copy(taskReminders = it)) }
          )
          ReminderToggleRow(
            title = "Sleep & Bedtime Wind-Down",
            checked = profile.sleepReminders,
            onCheckedChange = { viewModel.updateProfile(profile.copy(sleepReminders = it)) }
          )

          Spacer(modifier = Modifier.height(4.dp))

          OutlinedButton(
            onClick = {
              NotificationHelper.sendWaterReminder(context)
              Toast.makeText(context, "Test notification sent! Check shade.", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Filled.Notifications, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Send Test Notification")
          }
        }
      }
    }

    // PERMISSIONS STATUS DASHBOARD
    item {
      Text(
        text = "INTEGRATIONS & PERMISSIONS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          PermissionStatusRow(
            icon = Icons.Filled.DirectionsWalk,
            title = "Step Sensor / Activity",
            isGranted = hasActivity
          )
          PermissionStatusRow(
            icon = Icons.Filled.Notifications,
            title = "Push Notifications",
            isGranted = hasNotif
          )
          PermissionStatusRow(
            icon = Icons.Filled.PhoneAndroid,
            title = "Usage Access (Screen Time)",
            isGranted = hasUsage,
            onAction = { UsageStatsHelper.openUsageSettings(context) }
          )
          PermissionStatusRow(
            icon = Icons.Filled.Favorite,
            title = "Health Connect",
            isGranted = false,
            onAction = { sensorManager.openHealthConnectSettings(context) }
          )
        }
      }
    }

    // THEME MODE SELECTOR
    item {
      Text(
        text = "APPEARANCE",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(10.dp))
            Text("Theme Mode", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("system", "light", "dark").forEach { mode ->
              FilterChip(
                selected = profile.themeMode == mode,
                onClick = { viewModel.updateProfile(profile.copy(themeMode = mode)) },
                label = { Text(mode.replaceFirstChar { it.uppercase() }) }
              )
            }
          }
        }
      }
    }

    // DATA MANAGEMENT (Export, Reset)
    item {
      Text(
        text = "DATA MANAGEMENT",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                val summaryText = """
                  LifeOS Export
                  User: ${profile.name}
                  Steps Target: ${profile.stepTarget}
                  Water Target: ${profile.waterTargetMl}ml
                  Consistency: ${consistencyStats.consistencyPercentage}%
                """.trimIndent()
                val sendIntent = Intent().apply {
                  action = Intent.ACTION_SEND
                  putExtra(Intent.EXTRA_TEXT, summaryText)
                  type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Export LifeOS Data"))
              }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("Export Data Summary", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
              Text("Share or backup your system profile and targets", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { showResetDialog = true }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = Color(0xFFF43F5E))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("Reset System & History", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = Color(0xFFF43F5E))
              Text("Clear logged habits, tasks, and water history", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }

  // Edit Profile Dialog
  if (showEditProfileDialog) {
    EditProfileDialog(
      currentProfile = profile,
      onDismiss = { showEditProfileDialog = false },
      onSave = { updated ->
        viewModel.updateProfile(updated)
        showEditProfileDialog = false
      }
    )
  }

  // Reset Confirmation Dialog
  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      title = { Text("Reset LifeOS Data?", fontWeight = FontWeight.Bold) },
      text = { Text("This will clear your logged daily records, water entries, and reset active tasks. Core targets and habits will remain.") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.clearAllHistory()
            showResetDialog = false
            Toast.makeText(context, "History cleared successfully", Toast.LENGTH_SHORT).show()
          }
        ) {
          Text("Reset History")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
      }
    )
  }
}

@Composable
private fun StatPill(title: String, value: String, icon: ImageVector, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
      Spacer(modifier = Modifier.width(2.dp))
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
    Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}

@Composable
private fun ShortcutRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  color: Color,
  onClick: () -> Unit,
  testTag: String
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), modifier = Modifier.size(40.dp)) {
          Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
      Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
private fun TargetRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
  }
}

@Composable
private fun ReminderToggleRow(
  title: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    Switch(checked = checked, onCheckedChange = onCheckedChange)
  }
}

@Composable
private fun PermissionStatusRow(
  icon: ImageVector,
  title: String,
  isGranted: Boolean,
  onAction: (() -> Unit)? = null
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
      Spacer(modifier = Modifier.width(10.dp))
      Text(title, style = MaterialTheme.typography.bodyMedium)
    }
    if (isGranted) {
      Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF10B981).copy(alpha = 0.15f)) {
        Text("Active", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981), modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
      }
    } else {
      if (onAction != null) {
        OutlinedButton(onClick = onAction, modifier = Modifier.height(30.dp)) {
          Text("Enable", fontSize = 10.sp)
        }
      } else {
        Text("Inactive", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}

@Composable
private fun EditProfileDialog(
  currentProfile: UserProfile,
  onDismiss: () -> Unit,
  onSave: (UserProfile) -> Unit
) {
  var name by remember { mutableStateOf(currentProfile.name) }
  var age by remember { mutableStateOf(currentProfile.age.toString()) }
  var height by remember { mutableStateOf(currentProfile.heightCm.toString()) }
  var weight by remember { mutableStateOf(currentProfile.weightKg.toString()) }
  var stepTarget by remember { mutableStateOf(currentProfile.stepTarget.toString()) }
  var waterTarget by remember { mutableStateOf(currentProfile.waterTargetMl.toString()) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Edit Profile & Targets", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Age") }, modifier = Modifier.weight(1f))
          OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Height (cm)") }, modifier = Modifier.weight(1f))
          OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Weight (kg)") }, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = stepTarget, onValueChange = { stepTarget = it }, label = { Text("Step Target") }, modifier = Modifier.weight(1f))
          OutlinedTextField(value = waterTarget, onValueChange = { waterTarget = it }, label = { Text("Water (ml)") }, modifier = Modifier.weight(1f))
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val updated = currentProfile.copy(
            name = name.ifBlank { "Rahul" },
            age = age.toIntOrNull() ?: currentProfile.age,
            heightCm = height.toIntOrNull() ?: currentProfile.heightCm,
            weightKg = weight.toIntOrNull() ?: currentProfile.weightKg,
            stepTarget = stepTarget.toIntOrNull() ?: currentProfile.stepTarget,
            waterTargetMl = waterTarget.toIntOrNull() ?: currentProfile.waterTargetMl
          )
          onSave(updated)
        }
      ) {
        Text("Save Changes")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}
