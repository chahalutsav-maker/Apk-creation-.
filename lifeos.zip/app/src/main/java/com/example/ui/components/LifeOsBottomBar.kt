package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen

@Composable
fun LifeOsBottomBar(
  currentRoute: String,
  onNavigate: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val barBorder = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9)

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, barBorder),
    shadowElevation = 6.dp
  ) {
    NavigationBar(
      windowInsets = WindowInsets.navigationBars,
      containerColor = Color.Transparent,
      contentColor = MaterialTheme.colorScheme.onSurface,
      tonalElevation = 0.dp
    ) {
      Screen.bottomNavItems.filterNotNull().forEach { screen ->
        val isSelected = currentRoute == screen.route
        val icon = if (isSelected) screen.selectedIcon else screen.unselectedIcon

        NavigationBarItem(
          icon = {
            if (icon != null) {
              Icon(
                imageVector = icon,
                contentDescription = screen.title
              )
            }
          },
          label = {
            Text(
              text = screen.title,
              fontSize = 10.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
          },
          selected = isSelected,
          onClick = { onNavigate(screen) },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.primary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = if (isDark) Color(0xFF1E3A8A) else Color(0xFFDBEAFE),
            unselectedIconColor = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8),
            unselectedTextColor = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
          ),
          modifier = Modifier.testTag("nav_tab_${screen.route}")
        )
      }
    }
  }
}

