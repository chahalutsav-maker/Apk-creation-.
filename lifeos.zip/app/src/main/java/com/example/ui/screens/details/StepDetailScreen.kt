package com.example.ui.screens.details

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.HealthAndSensorManager
import com.example.ui.components.BarChartItem
import com.example.ui.components.MiniBarChart
import com.example.ui.theme.AccentSteps
import com.example.ui.viewmodel.LifeOsViewModel

@Composable
fun StepDetailScreen(
  viewModel: LifeOsViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val steps by viewModel.manualSteps.collectAsState()
  val analyticsData by viewModel.analyticsData.collectAsState()
  val context = LocalContext.current

  val sensorManager = remember { HealthAndSensorManager(context) }
  val sensorState = sensorManager.getSensorState()

  var showManualDialog by remember { mutableStateOf(false) }

  val targetSteps = userProfile?.stepTarget ?: 10000
  val heightCm = userProfile?.heightCm ?: 175
  val weightKg = userProfile?.weightKg ?: 70

  val distanceKm = HealthAndSensorManager.calculateDistanceKm(steps, heightCm)
  val calories = HealthAndSensorManager.calculateCalories(steps, weightKg)
  val progress = (steps.toFloat() / targetSteps).coerceIn(0f, 1f)

  val chartItems = analyticsData.takeLast(7).map {
    BarChartItem(
      label = it.dayLabel,
      value = it.steps.toFloat(),
      isHighlight = it.dateIso == viewModel.todayIso
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Bar
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Step Tracker 🚶",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Hero Steps Ring Card
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "DAILY STEPS PROGRESS",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = AccentSteps
          )

          Spacer(modifier = Modifier.height(18.dp))

          Box(contentAlignment = Alignment.Center, modifier = Modifier.size(150.dp)) {
            CircularProgressIndicator(
              progress = { 1f },
              modifier = Modifier.fillMaxSize(),
              color = AccentSteps.copy(alpha = 0.2f),
              strokeWidth = 14.dp,
              strokeCap = StrokeCap.Round
            )
            CircularProgressIndicator(
              progress = { progress },
              modifier = Modifier.fillMaxSize(),
              color = AccentSteps,
              strokeWidth = 14.dp,
              strokeCap = StrokeCap.Round
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = "$steps",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "of $targetSteps",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // 2 metric tiles (Distance and Calories)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            SubMetricTile(Icons.Filled.Route, "${distanceKm} km", "Distance", AccentSteps)
            SubMetricTile(Icons.Filled.LocalFireDepartment, "$calories kcal", "Calories", Color(0xFFF97316))
          }
        }
      }
    }

    // Sensor State / Manual Entry
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Hardware Step Counter", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
              text = if (sensorState.isSensorAvailable) "Sensor active & tracking" else "Using system / manual sync",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          OutlinedButton(onClick = { showManualDialog = true }) {
            Text("Adjust Steps")
          }
        }
      }
    }

    // 7-Day Steps Trend
    item {
      MiniBarChart(
        title = "7-Day Step History",
        subtitle = "Daily step count vs 10,000 target",
        items = chartItems,
        targetValue = targetSteps.toFloat(),
        barColor = AccentSteps,
        unit = "steps"
      )
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }

  // Adjust Steps Dialog
  if (showManualDialog) {
    var inputSteps by remember { mutableStateOf(steps.toString()) }
    AlertDialog(
      onDismissRequest = { showManualDialog = false },
      title = { Text("Update Steps", fontWeight = FontWeight.Bold) },
      text = {
        OutlinedTextField(
          value = inputSteps,
          onValueChange = { inputSteps = it },
          label = { Text("Total Steps Today") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val s = inputSteps.toIntOrNull() ?: steps
            viewModel.setManualSteps(s)
            showManualDialog = false
          }
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showManualDialog = false }) { Text("Cancel") }
      }
    )
  }
}

@Composable
private fun SubMetricTile(icon: ImageVector, value: String, label: String, color: Color) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), modifier = Modifier.size(36.dp)) {
      Box(contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
      }
    }
    Spacer(modifier = Modifier.width(8.dp))
    Column {
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}
