package com.example.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentSleep
import com.example.ui.theme.AccentSteps
import com.example.ui.theme.AccentWater
import com.example.ui.viewmodel.LifeOsViewModel
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class CalendarGridDay(
  val dateIso: String,
  val dayNumber: Int,
  val isCurrentMonth: Boolean,
  val isToday: Boolean,
  val score: Int
)

@Composable
fun CalendarScreen(
  viewModel: LifeOsViewModel,
  modifier: Modifier = Modifier
) {
  val selectedDate by viewModel.selectedCalendarDate.collectAsState()
  val summary by viewModel.calendarSummary.collectAsState()

  var calendarMonth by remember {
    mutableStateOf(Calendar.getInstance())
  }

  val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
  val monthTitle = monthFormat.format(calendarMonth.time)

  // Generate days in current month grid
  val gridDays = remember(calendarMonth) {
    val days = mutableListOf<CalendarGridDay>()
    val cal = calendarMonth.clone() as Calendar
    cal.set(Calendar.DAY_OF_MONTH, 1)

    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 for Sunday
    val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    // Leading padding days from previous month
    val prevCal = cal.clone() as Calendar
    prevCal.add(Calendar.MONTH, -1)
    val prevMax = prevCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    for (i in (prevMax - firstDayOfWeek + 1)..prevMax) {
      prevCal.set(Calendar.DAY_OF_MONTH, i)
      val iso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(prevCal.time)
      days.add(CalendarGridDay(iso, i, isCurrentMonth = false, isToday = false, score = 75))
    }

    // Days in current month
    val todayIso = DateUtils.todayIso()
    for (i in 1..maxDays) {
      cal.set(Calendar.DAY_OF_MONTH, i)
      val iso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
      val isToday = iso == todayIso
      val seed = (iso.hashCode() % 1000).let { if (it < 0) -it else it }
      val score = if (isToday) 84 else (70 + (seed % 28))
      days.add(CalendarGridDay(iso, i, isCurrentMonth = true, isToday = isToday, score = score))
    }

    // Trailing days
    val remaining = 42 - days.size
    val nextCal = cal.clone() as Calendar
    nextCal.add(Calendar.MONTH, 1)
    for (i in 1..remaining) {
      nextCal.set(Calendar.DAY_OF_MONTH, i)
      val iso = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(nextCal.time)
      days.add(CalendarGridDay(iso, i, isCurrentMonth = false, isToday = false, score = 70))
    }
    days
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Text(
        text = "Unified Calendar",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Review your historical lifestyle score and logs",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    // Month Navigation Card
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = monthTitle,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )

            Row {
              IconButton(
                onClick = {
                  val newCal = calendarMonth.clone() as Calendar
                  newCal.add(Calendar.MONTH, -1)
                  calendarMonth = newCal
                }
              ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Month")
              }
              IconButton(
                onClick = {
                  val newCal = calendarMonth.clone() as Calendar
                  newCal.add(Calendar.MONTH, 1)
                  calendarMonth = newCal
                }
              ) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Month")
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Day of week headers
          val daysOfWeek = listOf("S", "M", "T", "W", "T", "F", "S")
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            daysOfWeek.forEach { d ->
              Text(
                text = d,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 7x6 Calendar Grid
          LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            modifier = Modifier
              .fillMaxWidth()
              .height(260.dp),
            userScrollEnabled = false,
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            items(gridDays) { day ->
              val isSelected = day.dateIso == selectedDate
              val dotColor = when {
                day.score >= 80 -> Color(0xFF10B981) // Green
                day.score >= 60 -> Color(0xFFF59E0B) // Amber
                else -> Color(0xFFF43F5E) // Red
              }

              Box(
                modifier = Modifier
                  .aspectRatio(1f)
                  .clip(CircleShape)
                  .background(
                    if (isSelected) MaterialTheme.colorScheme.primary
                    else if (day.isToday) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    else Color.Transparent
                  )
                  .clickable {
                    viewModel.selectCalendarDate(day.dateIso)
                  }
                  .testTag("calendar_day_${day.dateIso}"),
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(
                    text = "${day.dayNumber}",
                    fontSize = 12.sp,
                    fontWeight = if (isSelected || day.isToday) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                    else if (day.isCurrentMonth) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                    textAlign = TextAlign.Center
                  )
                  if (day.isCurrentMonth) {
                    Box(
                      modifier = Modifier
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else dotColor)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // Selected Day Summary Card
    item {
      summary?.let { s ->
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "DAILY BREAKDOWN",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.1.sp,
                  color = MaterialTheme.colorScheme.primary
                )
                Text(
                  text = s.displayDate,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
              }

              Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("${s.dailyScore}/100", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
              }
            }

            CalendarSummaryRow(Icons.Filled.CheckCircle, "Tasks Completed", "${s.tasksCompleted} / ${s.tasksTotal} tasks", MaterialTheme.colorScheme.primary)
            CalendarSummaryRow(Icons.Filled.Repeat, "Habits Maintained", "${s.habitsCompleted} / ${s.habitsTotal} habits", MaterialTheme.colorScheme.secondary)
            CalendarSummaryRow(Icons.Filled.LocalDrink, "Water Consumed", "${s.waterMl} / ${s.waterTargetMl} ml", AccentWater)
            CalendarSummaryRow(Icons.Filled.DirectionsWalk, "Steps Logged", "${s.steps} / ${s.stepTarget} steps", AccentSteps)
            CalendarSummaryRow(Icons.Filled.Bedtime, "Sleep Duration", "${s.sleepMinutes / 60}h ${s.sleepMinutes % 60}m", AccentSleep)
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(84.dp))
    }
  }
}

@Composable
private fun CalendarSummaryRow(icon: ImageVector, title: String, value: String, color: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Surface(shape = CircleShape, color = color.copy(alpha = 0.15f), modifier = Modifier.size(32.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
      }
      Spacer(modifier = Modifier.width(10.dp))
      Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
    Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
  }
}
