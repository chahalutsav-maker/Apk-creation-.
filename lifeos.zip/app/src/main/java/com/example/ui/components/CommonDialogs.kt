package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.DateUtils

// 1. ADD TASK DIALOG
@Composable
fun AddTaskDialog(
  onDismiss: () -> Unit,
  onConfirm: (title: String, notes: String, priority: String, dueDate: String, dueTime: String, category: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var priority by remember { mutableStateOf("Medium") }
  var dueTime by remember { mutableStateOf("09:00 AM") }
  var category by remember { mutableStateOf("Personal") }

  val priorities = listOf("Low", "Medium", "High")
  val categories = listOf("Personal", "Work", "Fitness", "Study", "Health")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Add New Task",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Task Title *") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("task_title_input")
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Notes (Optional)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = dueTime,
          onValueChange = { dueTime = it },
          label = { Text("Due Time (e.g. 10:00 AM)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Text("Priority", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          priorities.forEach { p ->
            FilterChip(
              selected = priority == p,
              onClick = { priority = p },
              label = { Text(p) }
            )
          }
        }

        Text("Category", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          categories.take(3).forEach { c ->
            FilterChip(
              selected = category == c,
              onClick = { category = c },
              label = { Text(c, fontSize = 12.sp) }
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onConfirm(title, notes, priority, DateUtils.todayIso(), dueTime, category)
          }
        },
        enabled = title.isNotBlank(),
        modifier = Modifier.testTag("submit_task_button")
      ) {
        Text("Create Task")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

// 2. ADD HABIT DIALOG
@Composable
fun AddHabitDialog(
  onDismiss: () -> Unit,
  onConfirm: (name: String, iconName: String, colorHex: String, frequency: String, reminderTime: String) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var iconName by remember { mutableStateOf("check") }
  var selectedColorHex by remember { mutableStateOf("#0284C7") }
  var frequency by remember { mutableStateOf("Every day") }
  var reminderTime by remember { mutableStateOf("08:00 AM") }

  val frequencies = listOf("Every day", "Weekdays", "Custom")
  val colorOptions = listOf("#0284C7", "#10B981", "#8B5CF6", "#F59E0B", "#F43F5E", "#06B6D4")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Create Habit",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Habit Name (e.g. Morning Jog) *") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("habit_name_input")
        )

        OutlinedTextField(
          value = reminderTime,
          onValueChange = { reminderTime = it },
          label = { Text("Daily Reminder Time") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Text("Frequency", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          frequencies.forEach { f ->
            FilterChip(
              selected = frequency == f,
              onClick = { frequency = f },
              label = { Text(f) }
            )
          }
        }

        Text("Theme Color", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          colorOptions.forEach { hex ->
            val color = Color(android.graphics.Color.parseColor(hex))
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color)
                .clickable { selectedColorHex = hex }
                .then(
                  if (selectedColorHex == hex) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                  else Modifier
                )
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isNotBlank()) {
            onConfirm(name, iconName, selectedColorHex, frequency, reminderTime)
          }
        },
        enabled = name.isNotBlank(),
        modifier = Modifier.testTag("submit_habit_button")
      ) {
        Text("Save Habit")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

// 3. ADD WATER DIALOG
@Composable
fun AddWaterDialog(
  onDismiss: () -> Unit,
  onConfirm: (amountMl: Int) -> Unit
) {
  var customAmount by remember { mutableStateOf("250") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Log Water Intake 💧",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Text("Quick Add:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(100, 250, 500).forEach { ml ->
            OutlinedButton(
              onClick = {
                onConfirm(ml)
                onDismiss()
              },
              modifier = Modifier.weight(1f)
            ) {
              Text("+$ml ml")
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = customAmount,
          onValueChange = { customAmount = it },
          label = { Text("Custom Amount (ml)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val ml = customAmount.toIntOrNull() ?: 250
          onConfirm(ml)
        }
      ) {
        Text("Log Amount")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

// 4. ADD GOAL DIALOG
@Composable
fun AddGoalDialog(
  onDismiss: () -> Unit,
  onConfirm: (title: String, description: String, goalType: String, target: Double, unit: String, startDate: String, endDate: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var goalType by remember { mutableStateOf("Steps") }
  var targetValue by remember { mutableStateOf("300000") }
  var unit by remember { mutableStateOf("steps") }

  val goalTypes = listOf("Steps", "Water", "Habits", "Tasks", "Custom")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Create Target Goal 🎯",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Goal Title (e.g. Walk 300K Steps) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description") },
          modifier = Modifier.fillMaxWidth()
        )

        Text("Type", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          goalTypes.take(3).forEach { t ->
            FilterChip(
              selected = goalType == t,
              onClick = {
                goalType = t
                unit = when (t) {
                  "Steps" -> "steps"
                  "Water" -> "ml"
                  "Habits" -> "days"
                  "Tasks" -> "tasks"
                  else -> "units"
                }
              },
              label = { Text(t) }
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = targetValue,
            onValueChange = { targetValue = it },
            label = { Text("Target") },
            modifier = Modifier.weight(1.5f)
          )
          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text("Unit") },
            modifier = Modifier.weight(1f)
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val target = targetValue.toDoubleOrNull() ?: 100.0
          if (title.isNotBlank()) {
            onConfirm(title, description, goalType, target, unit, DateUtils.todayIso(), DateUtils.todayIso())
          }
        },
        enabled = title.isNotBlank()
      ) {
        Text("Save Goal")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

// 5. LOG SLEEP DIALOG
@Composable
fun LogSleepDialog(
  onDismiss: () -> Unit,
  onConfirm: (minutes: Int, bedtime: String, wakeTime: String, quality: String) -> Unit
) {
  var durationHours by remember { mutableStateOf("7") }
  var durationMinutes by remember { mutableStateOf("30") }
  var bedtime by remember { mutableStateOf("11:00 PM") }
  var wakeTime by remember { mutableStateOf("06:30 AM") }
  var quality by remember { mutableStateOf("Good") }

  val qualities = listOf("Great", "Good", "Fair", "Poor")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Log Sleep 😴",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = durationHours,
            onValueChange = { durationHours = it },
            label = { Text("Hours") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = durationMinutes,
            onValueChange = { durationMinutes = it },
            label = { Text("Minutes") },
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = bedtime,
            onValueChange = { bedtime = it },
            label = { Text("Bedtime") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = wakeTime,
            onValueChange = { wakeTime = it },
            label = { Text("Wake Time") },
            modifier = Modifier.weight(1f)
          )
        }

        Text("Quality", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          qualities.forEach { q ->
            FilterChip(
              selected = quality == q,
              onClick = { quality = q },
              label = { Text(q) }
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val hrs = durationHours.toIntOrNull() ?: 7
          val mins = durationMinutes.toIntOrNull() ?: 30
          val totalMins = (hrs * 60) + mins
          onConfirm(totalMins, bedtime, wakeTime, quality)
        }
      ) {
        Text("Save Sleep")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

// 6. DAILY SUMMARY DIALOG
@Composable
fun DailySummaryDialog(
  onDismiss: () -> Unit,
  steps: Int,
  stepTarget: Int,
  waterMl: Int,
  waterTargetMl: Int,
  sleepMinutes: Int,
  tasksCompleted: Int,
  tasksTotal: Int,
  habitsCompleted: Int,
  habitsTotal: Int,
  screenTimeFormatted: String,
  dailyScore: Int,
  motivationalMessage: String
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Your Day in Review", fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("Daily Score", style = MaterialTheme.typography.labelSmall)
            Text(
              text = "$dailyScore / 100",
              fontSize = 32.sp,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              text = motivationalMessage,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Medium
            )
          }
        }

        SummaryRow(Icons.Filled.DirectionsWalk, "Steps", "$steps / $stepTarget")
        SummaryRow(Icons.Filled.LocalDrink, "Water", "${(waterMl / 1000.0).let { "%.1f".format(it) }}L / ${(waterTargetMl / 1000.0).let { "%.1f".format(it) }}L")
        SummaryRow(Icons.Filled.Bedtime, "Sleep", "${sleepMinutes / 60}h ${sleepMinutes % 60}m")
        SummaryRow(Icons.Filled.CheckCircle, "Tasks", "$tasksCompleted / $tasksTotal")
        SummaryRow(Icons.Filled.Repeat, "Habits", "$habitsCompleted / $habitsTotal")
        SummaryRow(Icons.Filled.PhoneAndroid, "Screen Time", screenTimeFormatted)
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) { Text("Awesome!") }
    }
  )
}

@Composable
private fun SummaryRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
      Spacer(modifier = Modifier.width(8.dp))
      Text(label, style = MaterialTheme.typography.bodyMedium)
    }
    Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
  }
}
