package com.example.ui.screens.details

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AddWaterDialog
import com.example.ui.components.BarChartItem
import com.example.ui.components.MiniBarChart
import com.example.ui.theme.AccentWater
import com.example.ui.viewmodel.LifeOsViewModel
import com.example.util.DateUtils

@Composable
fun WaterDetailScreen(
  viewModel: LifeOsViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val userProfile by viewModel.userProfile.collectAsState()
  val todayWater by viewModel.todayWaterTotal.collectAsState()
  val waterLogs by viewModel.todayWaterLogs.collectAsState()
  val analyticsData by viewModel.analyticsData.collectAsState()

  var showCustomDialog by remember { mutableStateOf(false) }

  val targetWater = userProfile?.waterTargetMl ?: 2500
  val remainingWater = (targetWater - todayWater).coerceAtLeast(0)
  val progress = (todayWater.toFloat() / targetWater).coerceIn(0f, 1f)

  val chartItems = analyticsData.takeLast(7).map {
    BarChartItem(
      label = it.dayLabel,
      value = it.waterMl.toFloat(),
      isHighlight = it.dateIso == viewModel.todayIso
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Top Bar
    item {
      Spacer(modifier = Modifier.height(12.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Water Tracker 💧",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold
        )
      }
    }

    // Hero Hydration Progress Card
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "DAILY HYDRATION",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = AccentWater
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Glass Visualizer
          Box(
            modifier = Modifier
              .size(width = 120.dp, height = 150.dp)
              .clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp, topStart = 10.dp, topEnd = 10.dp))
              .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.BottomCenter
          ) {
            val animatedFill by animateFloatAsState(targetValue = progress, label = "waterGlassProgress")
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(150.dp * animatedFill)
                .background(
                  Brush.verticalGradient(
                    listOf(Color(0xFF38BDF8), AccentWater)
                  )
                )
            )

            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center
            ) {
              Text(
                text = "${(todayWater / 1000.0).let { "%.1f".format(it) }}L",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (progress > 0.4f) Color.White else MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "of ${(targetWater / 1000.0).let { "%.1f".format(it) }}L",
                fontSize = 12.sp,
                color = if (progress > 0.4f) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = if (remainingWater == 0) "🎉 Daily target reached! Outstanding hydration." else "${remainingWater}ml remaining to hit your target.",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    // Quick Add Buttons
    item {
      Text(
        text = "QUICK LOG",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        listOf(100, 250, 500).forEach { ml ->
          Button(
            onClick = { viewModel.addWater(ml) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("+$ml ml", fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      OutlinedButton(
        onClick = { showCustomDialog = true },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text("Custom Amount...")
      }
    }

    // 7-Day Hydration History Chart
    item {
      MiniBarChart(
        title = "7-Day Hydration Trend",
        subtitle = "Daily volume consumed vs target",
        items = chartItems,
        targetValue = targetWater.toFloat(),
        barColor = AccentWater,
        unit = "ml"
      )
    }

    // Today's Logged Intakes List
    item {
      Text(
        text = "TODAY'S ENTRIES",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        color = MaterialTheme.colorScheme.primary
      )
    }

    if (waterLogs.isEmpty()) {
      item {
        Text(
          text = "No water logged yet today. Take a sip!",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    } else {
      items(waterLogs) { log ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.LocalDrink, contentDescription = null, tint = AccentWater, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Text("${log.amountMl} ml", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(DateUtils.formatTime(log.timestamp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.width(8.dp))
              IconButton(onClick = { viewModel.deleteWaterLog(log.id) }, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(40.dp))
    }
  }

  if (showCustomDialog) {
    AddWaterDialog(
      onDismiss = { showCustomDialog = false },
      onConfirm = { ml ->
        viewModel.addWater(ml)
        showCustomDialog = false
      }
    )
  }
}
