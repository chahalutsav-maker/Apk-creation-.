package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentSleep
import com.example.ui.theme.AccentSteps
import com.example.ui.theme.AccentWater
import com.example.util.DailyScoreResult

@Composable
fun DailyScoreCard(
  scoreResult: DailyScoreResult,
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null
) {
  val isDark = MaterialTheme.colorScheme.background.red < 0.2f
  val bannerBg = if (isDark) Color(0xFF1E293B) else Color(0xFFEFF6FF)
  val bannerBorder = if (isDark) Color(0xFF334155) else Color(0xFFDBEAFE)
  val trackColor = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
  val ringColor = if (isDark) Color(0xFF60A5FA) else Color(0xFF3B82F6)
  val scoreTextColor = if (isDark) Color(0xFF93C5FD) else Color(0xFF1D4ED8)

  Card(
    modifier = modifier
      .fillMaxWidth()
      .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = bannerBg),
    border = BorderStroke(1.dp, bannerBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Circular Gauge matching SVG ring from Professional Polish design
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(64.dp)
            .padding(end = 4.dp)
        ) {
          val animatedProgress by animateFloatAsState(
            targetValue = (scoreResult.totalScore / 100f).coerceIn(0f, 1f),
            animationSpec = tween(durationMillis = 900),
            label = "scoreRingProgress"
          )

          Canvas(modifier = Modifier.size(56.dp)) {
            val strokeWidth = 5.5.dp.toPx()
            // Track
            drawCircle(
              color = trackColor,
              radius = (size.minDimension - strokeWidth) / 2,
              style = Stroke(width = strokeWidth)
            )
            // Progress
            drawArc(
              color = ringColor,
              startAngle = -90f,
              sweepAngle = 360f * animatedProgress,
              useCenter = false,
              style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
          }

          Text(
            text = "${scoreResult.totalScore}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = scoreTextColor
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Daily Lifestyle Score",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = if (isDark) Color(0xFFF1F5F9) else Color(0xFF1E293B)
            )
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (scoreResult.totalScore >= 80) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
            ) {
              Text(
                text = if (scoreResult.totalScore >= 80) "Optimal" else "Active",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (scoreResult.totalScore >= 80) Color(0xFF166534) else Color(0xFF92400E)
              )
            }
          }

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = scoreResult.message,
            style = MaterialTheme.typography.bodySmall,
            color = if (isDark) Color(0xFF94A3B8) else Color(0xFF475569),
            maxLines = 2
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 5 Mini Pillar Indicators
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        MetricScorePill(Icons.Filled.DirectionsWalk, "${scoreResult.stepsScore}/20", AccentSteps)
        MetricScorePill(Icons.Filled.LocalDrink, "${scoreResult.waterScore}/20", AccentWater)
        MetricScorePill(Icons.Filled.Bedtime, "${scoreResult.sleepScore}/20", AccentSleep)
        MetricScorePill(Icons.Filled.CheckCircle, "${scoreResult.tasksScore}/20", ringColor)
        MetricScorePill(Icons.Filled.Repeat, "${scoreResult.habitsScore}/20", Color(0xFF059669))
      }
    }
  }
}

@Composable
private fun MetricScorePill(icon: ImageVector, label: String, color: Color) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.padding(horizontal = 2.dp)
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = color,
      modifier = Modifier.size(13.dp)
    )
    Spacer(modifier = Modifier.width(3.dp))
    Text(
      text = label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

