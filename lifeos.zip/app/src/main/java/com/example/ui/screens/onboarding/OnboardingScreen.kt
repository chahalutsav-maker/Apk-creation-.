package com.example.ui.screens.onboarding

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.HealthAndSensorManager
import com.example.service.NotificationHelper
import com.example.service.UsageStatsHelper
import com.example.ui.theme.AccentSleep
import com.example.ui.theme.AccentSteps
import com.example.ui.theme.AccentWater

@Composable
fun OnboardingScreen(
  onFinishOnboarding: (
    name: String,
    age: Int,
    gender: String,
    heightCm: Int,
    weightKg: Int,
    stepTarget: Int,
    waterTargetMl: Int,
    sleepTargetMinutes: Int,
    wakeTime: String,
    sleepTime: String
  ) -> Unit,
  modifier: Modifier = Modifier
) {
  var currentStep by remember { mutableIntStateOf(1) }
  val context = LocalContext.current

  // Form states for Step 4
  var name by remember { mutableStateOf("Rahul") }
  var age by remember { mutableStateOf("26") }
  var gender by remember { mutableStateOf("Prefer not to say") }
  var heightCm by remember { mutableStateOf("175") }
  var weightKg by remember { mutableStateOf("70") }
  var stepTarget by remember { mutableStateOf("10000") }
  var waterTargetMl by remember { mutableStateOf("2500") }
  var sleepTargetMinutes by remember { mutableStateOf("480") }
  var wakeTime by remember { mutableStateOf("06:30 AM") }
  var sleepTime by remember { mutableStateOf("10:30 PM") }

  // Step 5 permission states
  val sensorManager = remember { HealthAndSensorManager(context) }
  var hasActivityPermission by remember { mutableStateOf(sensorManager.hasActivityRecognitionPermission()) }
  var hasNotifPermission by remember { mutableStateOf(NotificationHelper.hasNotificationPermission(context)) }
  var hasUsagePermission by remember { mutableStateOf(UsageStatsHelper.hasUsageStatsPermission(context)) }

  val activityPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    hasActivityPermission = isGranted
  }

  val notifPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    hasNotifPermission = isGranted
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 24.dp, vertical = 32.dp)
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Progress indicators
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.Center
      ) {
        for (i in 1..5) {
          Box(
            modifier = Modifier
              .padding(horizontal = 4.dp)
              .height(4.dp)
              .width(if (i == currentStep) 32.dp else 16.dp)
              .background(
                color = if (i <= currentStep) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                shape = RoundedCornerShape(2.dp)
              )
          )
        }
      }

      AnimatedContent(
        targetState = currentStep,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "onboarding_step_content",
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) { step ->
        when (step) {
          1 -> Step1Welcome(onNext = { currentStep = 2 })
          2 -> Step2TrackYourDay(onNext = { currentStep = 3 })
          3 -> Step3BuildConsistency(onNext = { currentStep = 4 })
          4 -> Step4PersonalSetup(
            name = name, onNameChange = { name = it },
            age = age, onAgeChange = { age = it },
            gender = gender, onGenderChange = { gender = it },
            height = heightCm, onHeightChange = { heightCm = it },
            weight = weightKg, onWeightChange = { weightKg = it },
            stepTarget = stepTarget, onStepTargetChange = { stepTarget = it },
            waterTarget = waterTargetMl, onWaterTargetChange = { waterTargetMl = it },
            wakeTime = wakeTime, onWakeTimeChange = { wakeTime = it },
            sleepTime = sleepTime, onSleepTimeChange = { sleepTime = it },
            onNext = { currentStep = 5 }
          )
          5 -> Step5Permissions(
            hasActivity = hasActivityPermission,
            onRequestActivity = {
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                activityPermissionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
              } else {
                hasActivityPermission = true
              }
            },
            hasNotif = hasNotifPermission,
            onRequestNotif = {
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              } else {
                hasNotifPermission = true
              }
            },
            hasUsage = hasUsagePermission,
            onRequestUsage = {
              UsageStatsHelper.openUsageSettings(context)
              hasUsagePermission = UsageStatsHelper.hasUsageStatsPermission(context)
            },
            onHealthConnectClick = {
              sensorManager.openHealthConnectSettings(context)
            },
            onFinish = {
              onFinishOnboarding(
                name.ifBlank { "Rahul" },
                age.toIntOrNull() ?: 26,
                gender,
                heightCm.toIntOrNull() ?: 175,
                weightKg.toIntOrNull() ?: 70,
                stepTarget.toIntOrNull() ?: 10000,
                waterTargetMl.toIntOrNull() ?: 2500,
                sleepTargetMinutes.toIntOrNull() ?: 480,
                wakeTime,
                sleepTime
              )
            }
          )
        }
      }
    }
  }
}

// SCREEN 1: WELCOME
@Composable
private fun Step1Welcome(onNext: () -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // LifeOS Hero Emblem
    Surface(
      shape = CircleShape,
      color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
      modifier = Modifier.size(110.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Filled.Shield,
          contentDescription = "LifeOS Logo",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(54.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    Text(
      text = "LifeOS",
      style = MaterialTheme.typography.headlineLarge,
      fontWeight = FontWeight.ExtraBold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Text(
      text = "Your Life. One System.",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.primary
    )

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "An all-in-one personal operating system that integrates your tasks, daily habits, hydration, steps, sleep, screen time, goals, and analytics into one clean flow.",
      style = MaterialTheme.typography.bodyLarge,
      textAlign = TextAlign.Center,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      lineHeight = 24.sp,
      modifier = Modifier.padding(horizontal = 12.dp)
    )

    Spacer(modifier = Modifier.height(36.dp))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_continue_1"),
      shape = RoundedCornerShape(16.dp)
    ) {
      Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.width(8.dp))
      Icon(Icons.Filled.ArrowForward, contentDescription = null)
    }
  }
}

// SCREEN 2: TRACK YOUR DAY
@Composable
private fun Step2TrackYourDay(onNext: () -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    Column {
      Text(
        text = "Track Your Day",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Maintain complete daily awareness without fragmented apps.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(20.dp))

      FeatureCard(Icons.Filled.CheckCircle, "Tasks", "Priority scheduling, tags, due times, and sub-items.", MaterialTheme.colorScheme.primary)
      FeatureCard(Icons.Filled.Repeat, "Habits", "Daily routines with visual streak counters and completion logs.", MaterialTheme.colorScheme.secondary)
      FeatureCard(Icons.Filled.LocalDrink, "Water Tracker", "Quick volume logs, custom targets, and hydration history.", AccentWater)
      FeatureCard(Icons.Filled.DirectionsWalk, "Steps & Distance", "Live sensor-driven step counts, distance, and calories.", AccentSteps)
      FeatureCard(Icons.Filled.Bedtime, "Sleep Recovery", "Bedtime tracking, duration logs, and quality scores.", AccentSleep)
      FeatureCard(Icons.Filled.PhoneAndroid, "Screen Time", "Android Usage Access integration with app breakdowns.", Color(0xFFF59E0B))
    }

    Spacer(modifier = Modifier.height(16.dp))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_continue_2"),
      shape = RoundedCornerShape(16.dp)
    ) {
      Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
  }
}

// SCREEN 3: BUILD CONSISTENCY
@Composable
private fun Step3BuildConsistency(onNext: () -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    Column {
      Text(
        text = "Build Consistency",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "Turn daily efforts into long-term compounding transformation.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(20.dp))

      FeatureCard(Icons.Filled.Whatshot, "Streaks & Guard", "Celebrate daily consistency and safeguard your momentum.", Color(0xFFF97316))
      FeatureCard(Icons.Filled.Flag, "Target Goals", "Long-term milestones across steps, hydration, tasks, and habits.", MaterialTheme.colorScheme.primary)
      FeatureCard(Icons.Filled.EmojiEvents, "30 to 90 Day Challenges", "Join structured disciplines like 10K Steps, Water Hero, and Mastery.", Color(0xFFEAB308))
      FeatureCard(Icons.Filled.Insights, "Analytics & Lifestyle Score", "Transparent 0-100 daily scoring and multi-week trend charts.", MaterialTheme.colorScheme.secondary)
    }

    Spacer(modifier = Modifier.height(24.dp))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_continue_3"),
      shape = RoundedCornerShape(16.dp)
    ) {
      Text("Continue to Setup", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
  }
}

// SCREEN 4: PERSONAL SETUP
@Composable
private fun Step4PersonalSetup(
  name: String, onNameChange: (String) -> Unit,
  age: String, onAgeChange: (String) -> Unit,
  gender: String, onGenderChange: (String) -> Unit,
  height: String, onHeightChange: (String) -> Unit,
  weight: String, onWeightChange: (String) -> Unit,
  stepTarget: String, onStepTargetChange: (String) -> Unit,
  waterTarget: String, onWaterTargetChange: (String) -> Unit,
  wakeTime: String, onWakeTimeChange: (String) -> Unit,
  sleepTime: String, onSleepTimeChange: (String) -> Unit,
  onNext: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(
      text = "Personal Setup",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )
    Text(
      text = "Personalize your targets. Optional fields can be skipped.",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    OutlinedTextField(
      value = name,
      onValueChange = onNameChange,
      label = { Text("Your Name *") },
      singleLine = true,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("onboarding_name_input")
    )

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      OutlinedTextField(
        value = age,
        onValueChange = onAgeChange,
        label = { Text("Age") },
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = gender,
        onValueChange = onGenderChange,
        label = { Text("Gender") },
        modifier = Modifier.weight(1.5f)
      )
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      OutlinedTextField(
        value = height,
        onValueChange = onHeightChange,
        label = { Text("Height (cm)") },
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = weight,
        onValueChange = onWeightChange,
        label = { Text("Weight (kg)") },
        modifier = Modifier.weight(1f)
      )
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      OutlinedTextField(
        value = stepTarget,
        onValueChange = onStepTargetChange,
        label = { Text("Daily Step Target") },
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = waterTarget,
        onValueChange = onWaterTargetChange,
        label = { Text("Water Target (ml)") },
        modifier = Modifier.weight(1f)
      )
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      OutlinedTextField(
        value = wakeTime,
        onValueChange = onWakeTimeChange,
        label = { Text("Wake Time") },
        modifier = Modifier.weight(1f)
      )
      OutlinedTextField(
        value = sleepTime,
        onValueChange = onSleepTimeChange,
        label = { Text("Bedtime") },
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    Button(
      onClick = onNext,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_continue_4"),
      shape = RoundedCornerShape(16.dp)
    ) {
      Text("Next: Permissions", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
  }
}

// SCREEN 5: PERMISSIONS
@Composable
private fun Step5Permissions(
  hasActivity: Boolean,
  onRequestActivity: () -> Unit,
  hasNotif: Boolean,
  onRequestNotif: () -> Unit,
  hasUsage: Boolean,
  onRequestUsage: () -> Unit,
  onHealthConnectClick: () -> Unit,
  onFinish: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Text(
        text = "Permissions & Integrations",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Text(
        text = "LifeOS respects your privacy and accesses only what you allow. You can grant or skip permissions individually.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      PermissionCard(
        icon = Icons.Filled.DirectionsWalk,
        title = "Physical Activity / Steps",
        description = "Allows live tracking of your daily steps from device sensors.",
        isGranted = hasActivity,
        buttonText = if (hasActivity) "Active" else "Grant Access",
        onAction = onRequestActivity
      )

      PermissionCard(
        icon = Icons.Filled.Favorite,
        title = "Health Connect",
        description = "Sync sleep and health records directly from Android Health.",
        isGranted = false,
        buttonText = "Configure",
        onAction = onHealthConnectClick
      )

      PermissionCard(
        icon = Icons.Filled.Notifications,
        title = "Notifications & Reminders",
        description = "Timely prompts for hydration, habit streaks, and sleep time.",
        isGranted = hasNotif,
        buttonText = if (hasNotif) "Active" else "Enable",
        onAction = onRequestNotif
      )

      PermissionCard(
        icon = Icons.Filled.PhoneAndroid,
        title = "Usage Access (Screen Time)",
        description = "Read daily foreground app time to detect and warn against excessive screen time.",
        isGranted = hasUsage,
        buttonText = if (hasUsage) "Active" else "Grant in Settings",
        onAction = onRequestUsage
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Button(
      onClick = onFinish,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("onboarding_finish_button"),
      shape = RoundedCornerShape(16.dp)
    ) {
      Text("Enter LifeOS", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
private fun FeatureCard(icon: ImageVector, title: String, description: String, color: Color) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = CircleShape,
        color = color.copy(alpha = 0.15f),
        modifier = Modifier.size(40.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}

@Composable
private fun PermissionCard(
  icon: ImageVector,
  title: String,
  description: String,
  isGranted: Boolean,
  buttonText: String,
  onAction: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isGranted) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
      else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      OutlinedButton(
        onClick = onAction,
        shape = RoundedCornerShape(12.dp),
        enabled = !isGranted
      ) {
        Text(buttonText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}
