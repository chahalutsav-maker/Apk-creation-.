package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
  val route: String,
  val title: String,
  val selectedIcon: ImageVector? = null,
  val unselectedIcon: ImageVector? = null
) {
  // 5 Primary Navigation Destinations
  data object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
  data object Tasks : Screen("tasks", "Tasks", Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle)
  data object Habits : Screen("habits", "Habits", Icons.Filled.Repeat, Icons.Outlined.Repeat)
  data object Calendar : Screen("calendar", "Calendar", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth)
  data object Profile : Screen("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)

  // Secondary Detail Destinations
  data object WaterDetail : Screen("water_detail", "Water Tracker")
  data object StepDetail : Screen("step_detail", "Step Tracker")
  data object SleepDetail : Screen("sleep_detail", "Sleep Tracker")
  data object ScreenTimeDetail : Screen("screentime_detail", "Screen Time")
  data object Goals : Screen("goals", "Goals")
  data object Challenges : Screen("challenges", "Challenges")
  data object Analytics : Screen("analytics", "Analytics")
  data object Onboarding : Screen("onboarding", "Welcome to LifeOS")

  companion object {
    val bottomNavItems: List<Screen>
      get() = listOf(Home, Tasks, Habits, Calendar, Profile)
  }
}
