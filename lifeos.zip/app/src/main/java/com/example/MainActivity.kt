package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.AddGoalDialog
import com.example.ui.components.AddHabitDialog
import com.example.ui.components.AddTaskDialog
import com.example.ui.components.AddWaterDialog
import com.example.ui.components.LifeOsBottomBar
import com.example.ui.components.QuickActionFab
import com.example.ui.navigation.Screen
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.details.AnalyticsScreen
import com.example.ui.screens.details.ChallengesScreen
import com.example.ui.screens.details.GoalsScreen
import com.example.ui.screens.details.ScreenTimeDetailScreen
import com.example.ui.screens.details.SleepDetailScreen
import com.example.ui.screens.details.StepDetailScreen
import com.example.ui.screens.details.WaterDetailScreen
import com.example.ui.screens.habits.HabitsScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.tasks.TasksScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.LifeOsViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: LifeOsViewModel = viewModel()
      val userProfile by viewModel.userProfile.collectAsState()

      val isDarkTheme = when (userProfile?.themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
      }

      MyApplicationTheme(darkTheme = isDarkTheme) {
        LifeOsApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun LifeOsApp(viewModel: LifeOsViewModel) {
  val userProfile by viewModel.userProfile.collectAsState()
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

  // Quick Action Dialog Triggers
  var showAddTaskDialog by remember { mutableStateOf(false) }
  var showAddHabitDialog by remember { mutableStateOf(false) }
  var showAddWaterDialog by remember { mutableStateOf(false) }
  var showAddGoalDialog by remember { mutableStateOf(false) }

  // Check onboarding completion
  val isOnboardingDone = userProfile?.isOnboardingCompleted == true

  if (!isOnboardingDone && userProfile != null) {
    OnboardingScreen(
      onFinishOnboarding = { name, age, gender, height, weight, steps, water, sleep, wake, sleepT ->
        viewModel.completeOnboarding(
          name = name,
          age = age,
          gender = gender,
          heightCm = height,
          weightKg = weight,
          stepTarget = steps,
          waterTargetMl = water,
          sleepTargetMinutes = sleep,
          wakeTime = wake,
          sleepTime = sleepT
        )
      }
    )
  } else {
    val isBottomBarVisible = currentRoute in Screen.bottomNavItems.mapNotNull { it?.route }

    Scaffold(
      modifier = Modifier.fillMaxSize(),
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      bottomBar = {
        if (isBottomBarVisible) {
          LifeOsBottomBar(
            currentRoute = currentRoute,
            onNavigate = { screen ->
              if (currentRoute != screen.route) {
                navController.navigate(screen.route) {
                  popUpTo(Screen.Home.route) { saveState = true }
                  launchSingleTop = true
                  restoreState = true
                }
              }
            }
          )
        }
      },
      floatingActionButton = {
        if (isBottomBarVisible && currentRoute == Screen.Home.route) {
          QuickActionFab(
            onAddTask = { showAddTaskDialog = true },
            onAddHabit = { showAddHabitDialog = true },
            onAddWater = { viewModel.addWater(250) },
            onAddGoal = { showAddGoalDialog = true },
            onStartChallenge = { navController.navigate(Screen.Challenges.route) }
          )
        }
      }
    ) { innerPadding ->
      NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        composable(Screen.Home.route) {
          HomeScreen(
            viewModel = viewModel,
            onNavigateToWater = { navController.navigate(Screen.WaterDetail.route) },
            onNavigateToSteps = { navController.navigate(Screen.StepDetail.route) },
            onNavigateToSleep = { navController.navigate(Screen.SleepDetail.route) },
            onNavigateToScreenTime = { navController.navigate(Screen.ScreenTimeDetail.route) },
            onNavigateToTasks = { navController.navigate(Screen.Tasks.route) },
            onNavigateToHabits = { navController.navigate(Screen.Habits.route) },
            onAddTaskClick = { showAddTaskDialog = true }
          )
        }

        composable(Screen.Tasks.route) {
          TasksScreen(
            viewModel = viewModel,
            onAddTaskClick = { showAddTaskDialog = true }
          )
        }

        composable(Screen.Habits.route) {
          HabitsScreen(
            viewModel = viewModel,
            onAddHabitClick = { showAddHabitDialog = true }
          )
        }

        composable(Screen.Calendar.route) {
          CalendarScreen(viewModel = viewModel)
        }

        composable(Screen.Profile.route) {
          ProfileScreen(
            viewModel = viewModel,
            onNavigateToGoals = { navController.navigate(Screen.Goals.route) },
            onNavigateToChallenges = { navController.navigate(Screen.Challenges.route) },
            onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) }
          )
        }

        // Secondary Detail Destinations
        composable(Screen.WaterDetail.route) {
          WaterDetailScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.StepDetail.route) {
          StepDetailScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.SleepDetail.route) {
          SleepDetailScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.ScreenTimeDetail.route) {
          ScreenTimeDetailScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.Goals.route) {
          GoalsScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.Challenges.route) {
          ChallengesScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }

        composable(Screen.Analytics.route) {
          AnalyticsScreen(
            viewModel = viewModel,
            onBack = { navController.popBackStack() }
          )
        }
      }
    }

    // Common Dialogs triggered from QuickAction or views
    if (showAddTaskDialog) {
      AddTaskDialog(
        onDismiss = { showAddTaskDialog = false },
        onConfirm = { title, notes, priority, dueDate, dueTime, category ->
          viewModel.addTask(title, notes, priority, dueDate, dueTime, category)
          showAddTaskDialog = false
        }
      )
    }

    if (showAddHabitDialog) {
      AddHabitDialog(
        onDismiss = { showAddHabitDialog = false },
        onConfirm = { name, icon, colorHex, freq, reminder ->
          viewModel.addHabit(name, icon, colorHex, freq, reminder)
          showAddHabitDialog = false
        }
      )
    }

    if (showAddWaterDialog) {
      AddWaterDialog(
        onDismiss = { showAddWaterDialog = false },
        onConfirm = { amount ->
          viewModel.addWater(amount)
          showAddWaterDialog = false
        }
      )
    }

    if (showAddGoalDialog) {
      AddGoalDialog(
        onDismiss = { showAddGoalDialog = false },
        onConfirm = { title, desc, type, target, unit, startD, endD ->
          viewModel.addGoal(title, desc, type, target, unit, startD, endD)
          showAddGoalDialog = false
        }
      )
    }
  }
}
