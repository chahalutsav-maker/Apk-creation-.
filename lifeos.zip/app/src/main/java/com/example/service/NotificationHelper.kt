package com.example.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {

  private const val CHANNEL_WATER = "lifeos_channel_water"
  private const val CHANNEL_HABITS = "lifeos_channel_habits"
  private const val CHANNEL_TASKS = "lifeos_channel_tasks"
  private const val CHANNEL_SLEEP = "lifeos_channel_sleep"
  private const val CHANNEL_SUMMARY = "lifeos_channel_summary"

  fun createNotificationChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        ?: return

      val channels = listOf(
        NotificationChannel(
          CHANNEL_WATER,
          "Water Reminders",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Prompts to hydrate and reach your daily target" },

        NotificationChannel(
          CHANNEL_HABITS,
          "Habit Reminders",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Daily alerts to protect your habit streaks" },

        NotificationChannel(
          CHANNEL_TASKS,
          "Task Reminders",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Timely alerts for your scheduled tasks" },

        NotificationChannel(
          CHANNEL_SLEEP,
          "Sleep & Bedtime",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Bedtime preparation and wind-down prompts" },

        NotificationChannel(
          CHANNEL_SUMMARY,
          "Daily Summary",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Evening review of your daily lifestyle score" }
      )

      channels.forEach { notificationManager.createNotificationChannel(it) }
    }
  }

  fun hasNotificationPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun sendWaterReminder(context: Context) {
    postNotification(
      context,
      CHANNEL_WATER,
      101,
      "Hydration Check 💧",
      "Time to drink some water! Log +250ml to stay on track."
    )
  }

  fun sendHabitReminder(context: Context, habitName: String = "Exercise", streak: Int = 5) {
    postNotification(
      context,
      CHANNEL_HABITS,
      102,
      "Keep Your Streak Alive 🔥",
      "Don't break your $streak-day streak! Check off '$habitName' today."
    )
  }

  fun sendTaskReminder(context: Context, taskTitle: String = "Complete daily review") {
    postNotification(
      context,
      CHANNEL_TASKS,
      103,
      "Task Reminder 📋",
      "Priority task pending: $taskTitle"
    )
  }

  fun sendSleepReminder(context: Context) {
    postNotification(
      context,
      CHANNEL_SLEEP,
      104,
      "Bedtime Approaching 😴",
      "Your sleep time is approaching. Dim screens for optimal recovery."
    )
  }

  fun sendDailySummary(context: Context, score: Int = 85, message: String = "Great day! Keep your streak alive!") {
    postNotification(
      context,
      CHANNEL_SUMMARY,
      105,
      "Your Day in Review: $score/100 ⭐",
      message
    )
  }

  private fun postNotification(
    context: Context,
    channelId: String,
    notificationId: Int,
    title: String,
    message: String
  ) {
    if (!hasNotificationPermission(context)) return

    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      context,
      0,
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val builder = NotificationCompat.Builder(context, channelId)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(message)
      .setStyle(NotificationCompat.BigTextStyle().bigText(message))
      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
      .setContentIntent(pendingIntent)
      .setAutoCancel(true)

    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    notificationManager?.notify(notificationId, builder.build())
  }
}
