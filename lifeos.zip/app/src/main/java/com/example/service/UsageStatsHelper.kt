package com.example.service

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.example.util.DateUtils

data class AppUsageInfo(
  val packageName: String,
  val appName: String,
  val usageMillis: Long,
  val usageFormatted: String
)

data class ScreenTimeStats(
  val isPermissionGranted: Boolean,
  val todayMillis: Long,
  val todayFormatted: String,
  val yesterdayMillis: Long,
  val yesterdayFormatted: String,
  val differenceMinutes: Int, // positive if more than yesterday
  val isExceedingTarget: Boolean,
  val topApps: List<AppUsageInfo>
)

object UsageStatsHelper {

  fun hasUsageStatsPermission(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
    val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      appOps.unsafeCheckOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
      )
    } else {
      @Suppress("DEPRECATION")
      appOps.checkOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
      )
    }
    return mode == AppOpsManager.MODE_ALLOWED
  }

  fun openUsageSettings(context: Context) {
    try {
      val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun getScreenTimeStats(context: Context, targetMinutes: Int = 180): ScreenTimeStats {
    val granted = hasUsageStatsPermission(context)
    if (!granted) {
      return ScreenTimeStats(
        isPermissionGranted = false,
        todayMillis = 0L,
        todayFormatted = "0h 0m",
        yesterdayMillis = 0L,
        yesterdayFormatted = "0h 0m",
        differenceMinutes = 0,
        isExceedingTarget = false,
        topApps = emptyList()
      )
    }

    val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
      ?: return ScreenTimeStats(
        isPermissionGranted = true,
        todayMillis = 0L,
        todayFormatted = "0h 0m",
        yesterdayMillis = 0L,
        yesterdayFormatted = "0h 0m",
        differenceMinutes = 0,
        isExceedingTarget = false,
        topApps = emptyList()
      )

    val now = System.currentTimeMillis()
    val startOfToday = DateUtils.getStartOfDay(now)
    val startOfYesterday = DateUtils.getStartOfYesterday()

    // 1. Query today's usage
    val todayStatsList: List<UsageStats> = try {
      usageStatsManager.queryUsageStats(
        UsageStatsManager.INTERVAL_DAILY,
        startOfToday,
        now
      ) ?: emptyList()
    } catch (e: Exception) {
      emptyList()
    }

    // 2. Query yesterday's usage
    val yesterdayStatsList: List<UsageStats> = try {
      usageStatsManager.queryUsageStats(
        UsageStatsManager.INTERVAL_DAILY,
        startOfYesterday,
        startOfToday
      ) ?: emptyList()
    } catch (e: Exception) {
      emptyList()
    }

    val pm = context.packageManager

    var totalTodayMillis = 0L
    val appUsageMap = mutableMapOf<String, Long>()

    for (stat in todayStatsList) {
      val time = stat.totalTimeInForeground
      if (time > 60_000) { // filter out < 1 min apps
        totalTodayMillis += time
        appUsageMap[stat.packageName] = (appUsageMap[stat.packageName] ?: 0L) + time
      }
    }

    var totalYesterdayMillis = 0L
    for (stat in yesterdayStatsList) {
      if (stat.totalTimeInForeground > 60_000) {
        totalYesterdayMillis += stat.totalTimeInForeground
      }
    }

    // Top apps
    val sortedApps = appUsageMap.entries
      .sortedByDescending { it.value }
      .take(6)
      .map { entry ->
        val appName = try {
          val appInfo = pm.getApplicationInfo(entry.key, 0)
          pm.getApplicationLabel(appInfo).toString()
        } catch (e: PackageManager.NameNotFoundException) {
          entry.key.substringAfterLast('.')
        }
        AppUsageInfo(
          packageName = entry.key,
          appName = appName,
          usageMillis = entry.value,
          usageFormatted = formatMillis(entry.value)
        )
      }

    val todayMinutes = (totalTodayMillis / (1000 * 60)).toInt()
    val yesterdayMinutes = (totalYesterdayMillis / (1000 * 60)).toInt()
    val diffMinutes = todayMinutes - yesterdayMinutes
    val isExceeding = todayMinutes > targetMinutes

    return ScreenTimeStats(
      isPermissionGranted = true,
      todayMillis = totalTodayMillis,
      todayFormatted = formatMillis(totalTodayMillis),
      yesterdayMillis = totalYesterdayMillis,
      yesterdayFormatted = formatMillis(totalYesterdayMillis),
      differenceMinutes = diffMinutes,
      isExceedingTarget = isExceeding,
      topApps = sortedApps
    )
  }

  fun formatMillis(millis: Long): String {
    val totalMinutes = millis / (1000 * 60)
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
  }
}
