package com.example.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat

data class StepSensorState(
  val isSensorAvailable: Boolean,
  val isPermissionGranted: Boolean,
  val liveSensorSteps: Int = 0
)

class HealthAndSensorManager(private val context: Context) : SensorEventListener {

  private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
  private val stepCounterSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

  private var initialSensorCount = -1
  private var currentSessionSteps = 0
  var onStepCountUpdated: ((Int) -> Unit)? = null

  fun hasActivityRecognitionPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACTIVITY_RECOGNITION
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun getSensorState(): StepSensorState {
    val hasPermission = hasActivityRecognitionPermission()
    val available = stepCounterSensor != null
    return StepSensorState(
      isSensorAvailable = available,
      isPermissionGranted = hasPermission,
      liveSensorSteps = currentSessionSteps
    )
  }

  fun startListening() {
    if (stepCounterSensor != null && hasActivityRecognitionPermission()) {
      sensorManager?.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI)
    }
  }

  fun stopListening() {
    sensorManager?.unregisterListener(this)
  }

  override fun onSensorChanged(event: SensorEvent?) {
    if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
      val totalSteps = event.values[0].toInt()
      if (initialSensorCount < 0) {
        initialSensorCount = totalSteps
      }
      currentSessionSteps = (totalSteps - initialSensorCount).coerceAtLeast(0)
      onStepCountUpdated?.invoke(currentSessionSteps)
    }
  }

  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

  // Health Connect integration helpers
  fun isHealthConnectInstalled(): Boolean {
    val pm = context.packageManager
    return try {
      pm.getPackageInfo("com.google.android.apps.healthdata", 0)
      true
    } catch (e: PackageManager.NameNotFoundException) {
      false
    }
  }

  fun openHealthConnectSettings(context: Context) {
    try {
      val intent = Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS").apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      // Fallback to Play Store if not installed
      try {
        val playStoreIntent = Intent(
          Intent.ACTION_VIEW,
          Uri.parse("market://details?id=com.google.android.apps.healthdata")
        ).apply {
          flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(playStoreIntent)
      } catch (e2: Exception) {
        e2.printStackTrace()
      }
    }
  }

  companion object {
    fun calculateDistanceKm(steps: Int, heightCm: Int = 175): Double {
      // Stride length formula: height * 0.415
      val strideMeters = (heightCm * 0.415) / 100.0
      val distanceMeters = steps * strideMeters
      return Math.round((distanceMeters / 1000.0) * 100.0) / 100.0
    }

    fun calculateCalories(steps: Int, weightKg: Int = 70): Int {
      // Approx 0.04 calories burned per step for average person, scaled by weight
      val factor = (weightKg / 70.0).coerceIn(0.7, 1.5)
      return (steps * 0.04 * factor).toInt()
    }
  }
}
