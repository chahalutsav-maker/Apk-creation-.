package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
  @PrimaryKey val id: Int = 1,
  val name: String = "Rahul",
  val age: Int = 26,
  val gender: String = "Prefer not to say",
  val heightCm: Int = 175,
  val weightKg: Int = 70,
  val stepTarget: Int = 10000,
  val waterTargetMl: Int = 2500,
  val sleepTargetMinutes: Int = 480, // 8 hours
  val screenTimeTargetMinutes: Int = 180, // 3 hours
  val wakeTime: String = "06:30 AM",
  val sleepTime: String = "10:30 PM",
  val isOnboardingCompleted: Boolean = false,
  val themeMode: String = "system", // "system", "light", "dark"
  val notificationsEnabled: Boolean = true,
  val waterReminders: Boolean = true,
  val habitReminders: Boolean = true,
  val taskReminders: Boolean = true,
  val sleepReminders: Boolean = true,
  val dailySummaryReminder: Boolean = true
)

@Entity(tableName = "tasks")
data class TaskItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val notes: String = "",
  val priority: String = "Medium", // "Low", "Medium", "High"
  val dueDate: String, // YYYY-MM-DD
  val dueTime: String = "", // e.g. "09:00 AM" or ""
  val category: String = "Personal", // "Personal", "Work", "Fitness", "Study", "Health"
  val isCompleted: Boolean = false,
  val completedAt: Long? = null,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
data class HabitItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val iconName: String = "check", // "exercise", "book", "water", "study", "meditation", "sleep", "sun", "heart"
  val colorHex: String = "#0284C7",
  val frequency: String = "Every day", // "Every day", "Weekdays", "Custom"
  val targetPerDay: Int = 1,
  val reminderTime: String = "08:00 AM",
  val currentStreak: Int = 0,
  val bestStreak: Int = 0,
  val totalCompletions: Int = 0,
  val createdAt: Long = System.currentTimeMillis(),
  val isArchived: Boolean = false
)

@Entity(
  tableName = "habit_logs",
  indices = [Index(value = ["habitId", "date"], unique = true)]
)
data class HabitLog(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val habitId: Long,
  val date: String, // YYYY-MM-DD
  val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "water_logs")
data class WaterLog(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val amountMl: Int,
  val date: String, // YYYY-MM-DD
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val goalType: String = "Steps", // "Steps", "Water", "Habits", "Tasks", "Custom"
  val targetValue: Double,
  val currentValue: Double = 0.0,
  val unit: String = "steps",
  val startDate: String,
  val endDate: String,
  val reminder: Boolean = true,
  val status: String = "Active", // "Active", "Paused", "Completed"
  val createdAt: Long = System.currentTimeMillis()
) {
  val completionPercentage: Int
    get() = if (targetValue > 0) ((currentValue / targetValue) * 100).toInt().coerceIn(0, 100) else 0
}

@Entity(tableName = "challenges")
data class ChallengeItem(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val description: String,
  val durationDays: Int, // 30, 60, 75, 90
  val challengeType: String, // "Steps", "Water", "Habit", "Tasks", "Sleep", "Discipline"
  val dailyRequirement: String,
  val startDate: String = "",
  val currentDay: Int = 1,
  val streak: Int = 0,
  val isJoined: Boolean = false,
  val isCompleted: Boolean = false
) {
  val progressPercentage: Int
    get() = if (durationDays > 0) ((currentDay.toDouble() / durationDays) * 100).toInt().coerceIn(0, 100) else 0
}

@Entity(tableName = "daily_records")
data class DailyRecord(
  @PrimaryKey val date: String, // YYYY-MM-DD
  val steps: Int = 0,
  val stepsTarget: Int = 10000,
  val distanceKm: Double = 0.0,
  val caloriesKcal: Int = 0,
  val waterMl: Int = 0,
  val waterTargetMl: Int = 2500,
  val sleepMinutes: Int = 0,
  val sleepTargetMinutes: Int = 480,
  val bedtime: String = "",
  val wakeTime: String = "",
  val sleepQuality: String = "Good", // "Great", "Good", "Fair", "Poor"
  val screenTimeMillis: Long = 0L,
  val yesterdayScreenTimeMillis: Long = 0L,
  val screenTimeWarning: Boolean = false,
  val tasksCompleted: Int = 0,
  val tasksTotal: Int = 0,
  val habitsCompleted: Int = 0,
  val habitsTotal: Int = 0,
  val dailyScore: Int = 0,
  val consistencyScore: Int = 0,
  val notes: String = ""
)

@Entity(tableName = "achievements")
data class Achievement(
  @PrimaryKey val id: String,
  val title: String,
  val description: String,
  val icon: String,
  val category: String = "general",
  val unlockedAt: Long? = null
)
