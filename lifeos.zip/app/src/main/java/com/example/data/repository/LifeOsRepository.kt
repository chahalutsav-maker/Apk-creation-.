package com.example.data.repository

import com.example.data.dao.LifeOsDao
import com.example.data.model.Achievement
import com.example.data.model.ChallengeItem
import com.example.data.model.DailyRecord
import com.example.data.model.GoalItem
import com.example.data.model.HabitItem
import com.example.data.model.HabitLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import com.example.util.DateUtils
import kotlinx.coroutines.flow.Flow

class LifeOsRepository(private val dao: LifeOsDao) {

  // --- USER PROFILE ---
  val userProfile: Flow<UserProfile?> = dao.getUserProfile()

  suspend fun getUserProfileDirect(): UserProfile? = dao.getUserProfileDirect()

  suspend fun updateProfile(profile: UserProfile) = dao.insertOrUpdateProfile(profile)

  // --- TASKS ---
  val allTasks: Flow<List<TaskItem>> = dao.getAllTasks()

  fun getTasksForDate(date: String): Flow<List<TaskItem>> = dao.getTasksForDate(date)

  suspend fun insertTask(task: TaskItem): Long {
    val id = dao.insertTask(task)
    checkAchievements()
    return id
  }

  suspend fun toggleTaskComplete(task: TaskItem) {
    val updated = task.copy(
      isCompleted = !task.isCompleted,
      completedAt = if (!task.isCompleted) System.currentTimeMillis() else null
    )
    dao.updateTask(updated)
    checkAchievements()
  }

  suspend fun updateTask(task: TaskItem) = dao.updateTask(task)

  suspend fun deleteTask(task: TaskItem) = dao.deleteTask(task)

  // --- HABITS ---
  val allHabits: Flow<List<HabitItem>> = dao.getAllHabits()

  fun getHabitLogsForDate(date: String): Flow<List<HabitLog>> = dao.getHabitLogsForDate(date)

  fun getLogsForHabit(habitId: Long): Flow<List<HabitLog>> = dao.getLogsForHabit(habitId)

  suspend fun insertHabit(habit: HabitItem): Long = dao.insertHabit(habit)

  suspend fun updateHabit(habit: HabitItem) = dao.updateHabit(habit)

  suspend fun deleteHabit(habit: HabitItem) = dao.deleteHabit(habit)

  suspend fun toggleHabitCompletion(habitId: Long, date: String): Boolean {
    val existing = dao.getHabitLog(habitId, date)
    val isNowCompleted: Boolean
    if (existing != null) {
      dao.deleteHabitLog(habitId, date)
      isNowCompleted = false
    } else {
      dao.insertHabitLog(HabitLog(habitId = habitId, date = date))
      isNowCompleted = true
    }
    recalculateHabitStreak(habitId)
    checkAchievements()
    return isNowCompleted
  }

  private suspend fun recalculateHabitStreak(habitId: Long) {
    val habit = dao.getHabitById(habitId) ?: return
    val logs = dao.getLogsForHabitDirect(habitId)
    val loggedDates = logs.map { it.date }.toSet()

    var streak = 0
    var checkDate = DateUtils.todayIso()
    val yesterday = DateUtils.yesterdayIso()

    // If today is completed, start from today. Otherwise, if yesterday was completed, streak is alive from yesterday
    val startFrom = if (loggedDates.contains(checkDate)) {
      checkDate
    } else if (loggedDates.contains(yesterday)) {
      yesterday
    } else {
      null
    }

    if (startFrom != null) {
      val allDates = DateUtils.getLastNDaysIso(60).reversed()
      val startIndex = allDates.indexOf(startFrom)
      if (startIndex >= 0) {
        for (i in startIndex downTo 0) {
          if (loggedDates.contains(allDates[i])) {
            streak++
          } else {
            break
          }
        }
      }
    }

    val bestStreak = maxOf(habit.bestStreak, streak)
    val updated = habit.copy(
      currentStreak = streak,
      bestStreak = bestStreak,
      totalCompletions = loggedDates.size
    )
    dao.updateHabit(updated)
  }

  // --- WATER ---
  fun getWaterLogsForDate(date: String): Flow<List<WaterLog>> = dao.getWaterLogsForDate(date)

  fun getWaterTotalForDate(date: String): Flow<Int> = dao.getWaterTotalForDate(date)

  suspend fun addWater(amountMl: Int, date: String = DateUtils.todayIso()): Long {
    val id = dao.insertWaterLog(WaterLog(amountMl = amountMl, date = date))
    checkAchievements()
    return id
  }

  suspend fun deleteWaterLog(id: Long) = dao.deleteWaterLogById(id)

  // --- GOALS ---
  val allGoals: Flow<List<GoalItem>> = dao.getAllGoals()

  suspend fun insertGoal(goal: GoalItem): Long = dao.insertGoal(goal)

  suspend fun updateGoal(goal: GoalItem) = dao.updateGoal(goal)

  suspend fun updateGoalProgress(goalId: Long, newProgress: Double) {
    val goals = dao.getAllGoals()
    // For direct update
  }

  suspend fun deleteGoal(goal: GoalItem) = dao.deleteGoal(goal)

  // --- CHALLENGES ---
  val allChallenges: Flow<List<ChallengeItem>> = dao.getAllChallenges()

  val joinedChallenges: Flow<List<ChallengeItem>> = dao.getJoinedChallenges()

  suspend fun updateChallenge(challenge: ChallengeItem) = dao.updateChallenge(challenge)

  suspend fun insertChallenge(challenge: ChallengeItem): Long = dao.insertChallenge(challenge)

  // --- DAILY RECORDS ---
  fun getDailyRecord(date: String): Flow<DailyRecord?> = dao.getDailyRecord(date)

  suspend fun getDailyRecordDirect(date: String): DailyRecord? = dao.getDailyRecordDirect(date)

  fun getRecentDailyRecords(limit: Int = 30): Flow<List<DailyRecord>> = dao.getRecentDailyRecords(limit)

  suspend fun getDailyRecordsForDates(dates: List<String>): List<DailyRecord> = dao.getDailyRecordsForDates(dates)

  suspend fun saveDailyRecord(record: DailyRecord) = dao.insertOrUpdateDailyRecord(record)

  // --- ACHIEVEMENTS ---
  val allAchievements: Flow<List<Achievement>> = dao.getAllAchievements()

  suspend fun checkAchievements() {
    val now = System.currentTimeMillis()
    // 1. Task master (100 completed tasks)
    val completedCount = dao.getCompletedTaskCount()
    if (completedCount >= 100) {
      dao.unlockAchievement("task_master", now)
    }

    // 2. Active days
    val activeDays = dao.getDistinctActiveHabitDaysCount()
    if (activeDays >= 7) {
      dao.unlockAchievement("first_week", now)
    }

    // 3. Habit streaks
    // Handled dynamically when streak >= 7 or >= 30
  }

  suspend fun unlockAchievementDirect(id: String) {
    dao.unlockAchievement(id, System.currentTimeMillis())
  }

  // --- DATA MANAGEMENT ---
  suspend fun clearHistory() {
    dao.clearAllHabitLogs()
    dao.clearAllWaterLogs()
    dao.clearAllDailyRecords()
  }

  suspend fun resetAllData() {
    dao.clearAllTasks()
    dao.clearAllHabitLogs()
    dao.clearAllWaterLogs()
    dao.clearAllDailyRecords()
    dao.clearAllGoals()
  }
}
