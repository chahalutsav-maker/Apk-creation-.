package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.LifeOsDao
import com.example.data.model.Achievement
import com.example.data.model.ChallengeItem
import com.example.data.model.DailyRecord
import com.example.data.model.GoalItem
import com.example.data.model.HabitItem
import com.example.data.model.HabitLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    UserProfile::class,
    TaskItem::class,
    HabitItem::class,
    HabitLog::class,
    WaterLog::class,
    GoalItem::class,
    ChallengeItem::class,
    DailyRecord::class,
    Achievement::class
  ],
  version = 1,
  exportSchema = false
)
abstract class LifeOsDatabase : RoomDatabase() {
  abstract fun lifeOsDao(): LifeOsDao

  companion object {
    @Volatile
    private var INSTANCE: LifeOsDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): LifeOsDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          LifeOsDatabase::class.java,
          "lifeos_database"
        )
          .addCallback(DatabaseCallback(scope))
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class DatabaseCallback(
    private val scope: CoroutineScope
  ) : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        scope.launch(Dispatchers.IO) {
          prepopulateDatabase(database.lifeOsDao())
        }
      }
    }

    suspend fun prepopulateDatabase(dao: LifeOsDao) {
      // 1. Initial User Profile
      dao.insertOrUpdateProfile(
        UserProfile(
          id = 1,
          name = "Rahul",
          age = 26,
          gender = "Not specified",
          heightCm = 175,
          weightKg = 70,
          stepTarget = 10000,
          waterTargetMl = 2500,
          sleepTargetMinutes = 480,
          screenTimeTargetMinutes = 180,
          wakeTime = "06:30 AM",
          sleepTime = "10:30 PM",
          isOnboardingCompleted = false,
          themeMode = "system"
        )
      )

      // 2. Default Habits
      val defaultHabits = listOf(
        HabitItem(name = "Exercise & Stretching", iconName = "exercise", colorHex = "#10B981", frequency = "Every day", reminderTime = "07:00 AM"),
        HabitItem(name = "Read 20 minutes", iconName = "book", colorHex = "#6366F1", frequency = "Every day", reminderTime = "09:00 PM"),
        HabitItem(name = "Drink 2.5L Water", iconName = "water", colorHex = "#0284C7", frequency = "Every day", reminderTime = "11:00 AM"),
        HabitItem(name = "Deep Study / Focus", iconName = "study", colorHex = "#8B5CF6", frequency = "Weekdays", reminderTime = "02:00 PM"),
        HabitItem(name = "10 Min Meditation", iconName = "meditation", colorHex = "#EC4899", frequency = "Every day", reminderTime = "06:45 AM"),
        HabitItem(name = "Sleep before 11 PM", iconName = "sleep", colorHex = "#F59E0B", frequency = "Every day", reminderTime = "10:15 PM")
      )
      defaultHabits.forEach { dao.insertHabit(it) }

      // 3. Predefined Challenges
      val predefinedChallenges = listOf(
        ChallengeItem(
          name = "30-Day 10K Steps Challenge",
          description = "Hit 10,000 steps every single day for 30 consecutive days.",
          durationDays = 30,
          challengeType = "Steps",
          dailyRequirement = "10,000 steps",
          isJoined = true,
          currentDay = 1
        ),
        ChallengeItem(
          name = "30-Day Daily Water (Hydration Hero)",
          description = "Drink at least 2.5 liters of water every day to flush toxins and stay alert.",
          durationDays = 30,
          challengeType = "Water",
          dailyRequirement = "2,500 ml",
          isJoined = true,
          currentDay = 1
        ),
        ChallengeItem(
          name = "30-Day No Missed Habit",
          description = "Complete all core daily habits without breaking the streak.",
          durationDays = 30,
          challengeType = "Habit",
          dailyRequirement = "All daily habits",
          isJoined = false,
          currentDay = 1
        ),
        ChallengeItem(
          name = "30-Day Daily Task Completion",
          description = "Check off all planned tasks before going to bed.",
          durationDays = 30,
          challengeType = "Tasks",
          dailyRequirement = "100% daily tasks",
          isJoined = false,
          currentDay = 1
        ),
        ChallengeItem(
          name = "30-Day Sleep Consistency",
          description = "Maintain a regular sleep schedule with at least 7.5 to 8 hours of sleep.",
          durationDays = 30,
          challengeType = "Sleep",
          dailyRequirement = "8 hours sleep",
          isJoined = false,
          currentDay = 1
        ),
        ChallengeItem(
          name = "60-Day Body & Mind Transformation",
          description = "Complete steps, hydration, workout, and reading habits daily.",
          durationDays = 60,
          challengeType = "Discipline",
          dailyRequirement = "Steps + Water + Reading",
          isJoined = false,
          currentDay = 1
        ),
        ChallengeItem(
          name = "75-Day Hard Discipline",
          description = "No cheat days. 2 workouts, 3L water, 10 pages read, strict sleep.",
          durationDays = 75,
          challengeType = "Discipline",
          dailyRequirement = "Complete daily protocol",
          isJoined = false,
          currentDay = 1
        ),
        ChallengeItem(
          name = "90-Day Mastery Challenge",
          description = "Total life overhaul across productivity, fitness, health, and mindfulness.",
          durationDays = 90,
          challengeType = "Discipline",
          dailyRequirement = "Maintain >80% Life Score",
          isJoined = false,
          currentDay = 1
        )
      )
      dao.insertAllChallenges(predefinedChallenges)

      // 4. Predefined Achievements
      val predefinedAchievements = listOf(
        Achievement(
          id = "first_week",
          title = "First Week",
          description = "Complete 7 active days in LifeOS.",
          icon = "trophy"
        ),
        Achievement(
          id = "streak_7",
          title = "7 Day Streak",
          description = "Maintain a 7-day habit streak.",
          icon = "fire"
        ),
        Achievement(
          id = "streak_30",
          title = "30 Day Streak",
          description = "Maintain a 30-day streak.",
          icon = "fire_double"
        ),
        Achievement(
          id = "steps_100k",
          title = "100K Steps",
          description = "Reach 100,000 total steps logged.",
          icon = "shoe"
        ),
        Achievement(
          id = "hydration_master",
          title = "Hydration Master",
          description = "Hit your daily water target for 30 days.",
          icon = "drop"
        ),
        Achievement(
          id = "task_master",
          title = "Task Master",
          description = "Complete 100 tasks in LifeOS.",
          icon = "tasks"
        ),
        Achievement(
          id = "challenge_completed",
          title = "Challenge Completed",
          description = "Complete a full 30, 60, 75, or 90 day challenge.",
          icon = "badge"
        )
      )
      dao.insertAllAchievements(predefinedAchievements)
    }
  }
}
