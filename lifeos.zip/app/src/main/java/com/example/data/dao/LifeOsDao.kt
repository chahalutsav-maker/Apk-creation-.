package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Achievement
import com.example.data.model.ChallengeItem
import com.example.data.model.DailyRecord
import com.example.data.model.GoalItem
import com.example.data.model.HabitItem
import com.example.data.model.HabitLog
import com.example.data.model.TaskItem
import com.example.data.model.UserProfile
import com.example.data.model.WaterLog
import kotlinx.coroutines.flow.Flow

@Dao
interface LifeOsDao {

  // --- USER PROFILE ---
  @Query("SELECT * FROM user_profile WHERE id = 1")
  fun getUserProfile(): Flow<UserProfile?>

  @Query("SELECT * FROM user_profile WHERE id = 1")
  suspend fun getUserProfileDirect(): UserProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateProfile(profile: UserProfile)

  // --- TASKS ---
  @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDate ASC, priority DESC")
  fun getAllTasks(): Flow<List<TaskItem>>

  @Query("SELECT * FROM tasks WHERE dueDate = :date ORDER BY isCompleted ASC, dueTime ASC, priority DESC")
  fun getTasksForDate(date: String): Flow<List<TaskItem>>

  @Query("SELECT * FROM tasks WHERE dueDate = :date")
  suspend fun getTasksForDateDirect(date: String): List<TaskItem>

  @Query("SELECT COUNT(*) FROM tasks WHERE isCompleted = 1")
  suspend fun getCompletedTaskCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskItem): Long

  @Update
  suspend fun updateTask(task: TaskItem)

  @Delete
  suspend fun deleteTask(task: TaskItem)

  // --- HABITS ---
  @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY createdAt ASC")
  fun getAllHabits(): Flow<List<HabitItem>>

  @Query("SELECT * FROM habits WHERE id = :id")
  suspend fun getHabitById(id: Long): HabitItem?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabit(habit: HabitItem): Long

  @Update
  suspend fun updateHabit(habit: HabitItem)

  @Delete
  suspend fun deleteHabit(habit: HabitItem)

  // --- HABIT LOGS ---
  @Query("SELECT * FROM habit_logs WHERE date = :date")
  fun getHabitLogsForDate(date: String): Flow<List<HabitLog>>

  @Query("SELECT * FROM habit_logs WHERE date = :date")
  suspend fun getHabitLogsForDateDirect(date: String): List<HabitLog>

  @Query("SELECT * FROM habit_logs WHERE habitId = :habitId ORDER BY date DESC")
  fun getLogsForHabit(habitId: Long): Flow<List<HabitLog>>

  @Query("SELECT * FROM habit_logs WHERE habitId = :habitId ORDER BY date DESC")
  suspend fun getLogsForHabitDirect(habitId: Long): List<HabitLog>

  @Query("SELECT * FROM habit_logs WHERE habitId = :habitId AND date = :date LIMIT 1")
  suspend fun getHabitLog(habitId: Long, date: String): HabitLog?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabitLog(log: HabitLog): Long

  @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND date = :date")
  suspend fun deleteHabitLog(habitId: Long, date: String)

  @Query("SELECT COUNT(DISTINCT date) FROM habit_logs")
  suspend fun getDistinctActiveHabitDaysCount(): Int

  // --- WATER LOGS ---
  @Query("SELECT * FROM water_logs WHERE date = :date ORDER BY timestamp DESC")
  fun getWaterLogsForDate(date: String): Flow<List<WaterLog>>

  @Query("SELECT COALESCE(SUM(amountMl), 0) FROM water_logs WHERE date = :date")
  fun getWaterTotalForDate(date: String): Flow<Int>

  @Query("SELECT COALESCE(SUM(amountMl), 0) FROM water_logs WHERE date = :date")
  suspend fun getWaterTotalForDateDirect(date: String): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertWaterLog(waterLog: WaterLog): Long

  @Delete
  suspend fun deleteWaterLog(waterLog: WaterLog)

  @Query("DELETE FROM water_logs WHERE id = :id")
  suspend fun deleteWaterLogById(id: Long)

  // --- GOALS ---
  @Query("SELECT * FROM goals ORDER BY status ASC, createdAt DESC")
  fun getAllGoals(): Flow<List<GoalItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGoal(goal: GoalItem): Long

  @Update
  suspend fun updateGoal(goal: GoalItem)

  @Delete
  suspend fun deleteGoal(goal: GoalItem)

  // --- CHALLENGES ---
  @Query("SELECT * FROM challenges ORDER BY isJoined DESC, durationDays ASC")
  fun getAllChallenges(): Flow<List<ChallengeItem>>

  @Query("SELECT * FROM challenges WHERE isJoined = 1 ORDER BY currentDay DESC")
  fun getJoinedChallenges(): Flow<List<ChallengeItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertChallenge(challenge: ChallengeItem): Long

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertAllChallenges(challenges: List<ChallengeItem>)

  @Update
  suspend fun updateChallenge(challenge: ChallengeItem)

  // --- DAILY RECORDS ---
  @Query("SELECT * FROM daily_records WHERE date = :date LIMIT 1")
  fun getDailyRecord(date: String): Flow<DailyRecord?>

  @Query("SELECT * FROM daily_records WHERE date = :date LIMIT 1")
  suspend fun getDailyRecordDirect(date: String): DailyRecord?

  @Query("SELECT * FROM daily_records ORDER BY date DESC LIMIT :limit")
  fun getRecentDailyRecords(limit: Int): Flow<List<DailyRecord>>

  @Query("SELECT * FROM daily_records WHERE date IN (:dates)")
  suspend fun getDailyRecordsForDates(dates: List<String>): List<DailyRecord>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateDailyRecord(record: DailyRecord)

  // --- ACHIEVEMENTS ---
  @Query("SELECT * FROM achievements")
  fun getAllAchievements(): Flow<List<Achievement>>

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertAllAchievements(achievements: List<Achievement>)

  @Query("UPDATE achievements SET unlockedAt = :timestamp WHERE id = :id AND unlockedAt IS NULL")
  suspend fun unlockAchievement(id: String, timestamp: Long)

  // --- DATA MANAGEMENT ---
  @Query("DELETE FROM tasks")
  suspend fun clearAllTasks()

  @Query("DELETE FROM habit_logs")
  suspend fun clearAllHabitLogs()

  @Query("DELETE FROM water_logs")
  suspend fun clearAllWaterLogs()

  @Query("DELETE FROM daily_records")
  suspend fun clearAllDailyRecords()

  @Query("DELETE FROM goals")
  suspend fun clearAllGoals()
}
